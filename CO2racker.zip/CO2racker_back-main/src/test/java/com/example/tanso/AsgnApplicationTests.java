package com.example.tanso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsgnApplicationTests {

    @Test
    void contextLoads() {
    }

}
