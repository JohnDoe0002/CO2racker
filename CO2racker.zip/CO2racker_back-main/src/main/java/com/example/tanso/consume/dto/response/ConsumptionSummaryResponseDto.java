package com.example.tanso.consume.dto.response;

public class ConsumptionSummaryResponseDto {
}
