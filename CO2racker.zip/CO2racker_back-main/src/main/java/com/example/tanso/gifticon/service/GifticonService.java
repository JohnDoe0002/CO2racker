package com.example.tanso.gifticon.service;

import com.example.tanso.boot.exception.RestException;
import com.example.tanso.user.domain.model.User;
import com.example.tanso.user.domain.repository.UserRepository;
import com.example.tanso.user.dto.response.UserDetailsImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class GifticonService {

    private final UserRepository userRepository;

    @Transactional
    public boolean purchaseGifticon() throws Exception {
        UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User userEntity = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new RestException(HttpStatus.NOT_FOUND, "일치하는 유저를 찾을 수 없습니다. userId=" + userDetails.getId()));

        // 현재 유저가 지닌 포인트가 5000 포인트 이상인지 확인한다.
        if (userEntity.getPoint() < 5000) {
            throw new RestException(HttpStatus.BAD_REQUEST, "포인트가 부족합니다. point=" + userEntity.getPoint());
        }

        // 현재 유저의 포인트를 5000포인트 차감한다.
        userEntity.decreasePoint(5000);

        // 유저의 기프티콘 보유 개수를 증가시킨다.
        userEntity.increaseGifticonCount();

        return true;
    }

}
