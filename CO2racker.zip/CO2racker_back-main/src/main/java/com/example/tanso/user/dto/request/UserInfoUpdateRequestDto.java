package com.example.tanso.user.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserInfoUpdateRequestDto {

    @ApiModelProperty(value = "닉네임")
    private String nickname;

    @ApiModelProperty(value = "기본 주소")
    private String addr;

    @ApiModelProperty(value = "상세 주소")
    private String detailAddr;

    @ApiModelProperty(value = "비밀번호")
    private String password;

}
