package com.example.tanso.consume.enums;

public enum ConsumptionType {
    ELEC, GAS, WATER
}
