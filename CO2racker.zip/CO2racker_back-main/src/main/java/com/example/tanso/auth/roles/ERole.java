package com.example.tanso.auth.roles;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
