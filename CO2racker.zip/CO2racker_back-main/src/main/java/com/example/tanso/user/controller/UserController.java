package com.example.tanso.user.controller;

import com.example.tanso.user.dto.request.UserInfoUpdateRequestDto;
import com.example.tanso.user.dto.response.UserDetailsImpl;
import com.example.tanso.user.dto.response.UserResponseDto;
import com.example.tanso.user.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Api(tags = {"[App] 유저 API/마이페이지"})
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    @GetMapping("/info")
    @ApiOperation(value = "회원 정보 조회 API", notes = "Authorization 헤더를 통해 유저 Access Token 을 전달받아 해당하는 유저의 정보를 조회한다.")
    @ApiResponses({
            @ApiResponse(code = 200, message = "조회 성공", response = UserDetailsImpl.class)
    })
    public ResponseEntity<UserDetailsImpl> findUserInfo(@RequestHeader(HttpHeaders.AUTHORIZATION) String authorization) throws Exception {
        return new ResponseEntity<>(userService.findUserInfo(), HttpStatus.OK);
    }

    @PatchMapping("/update")
    @ApiOperation(value = "회원 정보 수정 API", notes = "DTO 를 전달받아 해당하는 유저의 정보를 수정한다.")
    @ApiResponses({
            @ApiResponse(code = 200, message = "수정 성공"),
            @ApiResponse(code = 404, message = "수정 실패 - 유저 미조회")
    })
    public ResponseEntity<UserResponseDto> updateUser(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String authorization,
            @RequestBody UserInfoUpdateRequestDto requestDto
            ) throws Exception {
        return new ResponseEntity<>(userService.updateUser(requestDto), HttpStatus.OK);
    }
}
