package com.example.tanso.user.scheduler;

import com.example.tanso.boot.exception.RestException;
import com.example.tanso.boot.utils.StringUtils;
import com.example.tanso.consume.domain.model.Consumption;
import com.example.tanso.consume.domain.repository.ConsumptionRepository;
import com.example.tanso.user.domain.model.User;
import com.example.tanso.user.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class UserPointScheduler {

    private final UserRepository userRepository;
    private final ConsumptionRepository consumptionRepository;

    // 매 자정마다 당일 소비량이 가장 적었던 유저에게 포인트를 지급한다.
    @Scheduled(cron = "0/10 * * * * *")
    @Transactional
    public void pointSchedule() {
        log.info("포인트 스케쥴러를 동작합니다.");

        // 오늘 및 다음 날 날짜
        LocalDateTime today = LocalDate.now().atStartOfDay();
        LocalDateTime endOfToday = LocalDate.now().atTime(LocalTime.MAX.withNano(0));

        // 각 구 별 데이터를 모두 가져온 후, 해당 구에 속한 각 데이터를 가져온다.
        List<User> userEntityList = userRepository.findAll();
        List<String> userAddressList = userEntityList.stream()
                .map(User::getAddr)
                .collect(Collectors.toList());

        Set<String> guList = userAddressList.stream()
                .map(eachAddr -> new StringUtils().getGuFromAddress(eachAddr))
                .collect(Collectors.toSet());

        log.info("구 리스트: " + guList);

        for (String eachGu : guList) {
            Map<Long, Double> todayConsumedRankMap = new HashMap<>();
            List<Consumption> todayConsumptionEntityList = consumptionRepository.findAllByAreaAndCreatedAtBetween(eachGu, today, endOfToday);

            // 각 유저 별 오늘 전체 소비량을 계산한다.
            for (Consumption eachConsumption : todayConsumptionEntityList) {
                // 만일, 소비 랭킹 맵에 현재 유저에 대한 시퀀스가 없을 경우 초기화한다.
                if (!todayConsumedRankMap.containsKey(eachConsumption.getUserId())) {
                    todayConsumedRankMap.put(eachConsumption.getUserId(), 0.0);
                }

                todayConsumedRankMap.compute(eachConsumption.getUserId(), (aLong, aDouble) -> aDouble + eachConsumption.getConsumed());
            }

            // 산출된 Map 을 바탕으로 Value 별로 정렬한다. (순위) 이후, 3위까지의 데이터만 취한다.
            List<Map.Entry<Long, Double>> entries = todayConsumedRankMap.entrySet().stream()
                    .sorted(Map.Entry.comparingByValue())
                    .collect(Collectors.toList());

            List<Map.Entry<Long, Double>> subEntriesUpTo3 = new ArrayList<>();

            for(int i=0; i<3; i++) {
                if (entries.size() == (i)) {
                    break;
                }
                subEntriesUpTo3.add(entries.get(i));
            }

            // 3위까지의 유저 아이디를 취한 후, 해당하는 유저의 순위 별로 포인트를 지급한다.
            log.info(eachGu + " 내 사용 랭킹 계산 결과");
            log.info(subEntriesUpTo3.toString());

            int rank = 1;
            for (Map.Entry<Long, Double> eachEntry : subEntriesUpTo3) {
                Long userId = eachEntry.getKey();
                User userEntity = userEntityList.stream()
                        .filter(element -> element.getId().equals(userId))
                        .findFirst()
                        .orElseThrow(() -> new RestException(HttpStatus.NOT_FOUND, "일치하는 유저를 찾을 수 없습니다. userId=" + userId));

                if (rank == 1) {
                    userEntity.increasePoint(5000);
                } else if (rank == 2) {
                    userEntity.increasePoint(2000);
                } else if (rank == 3) {
                    userEntity.increasePoint(1000);
                } else {
                    continue;
                }

                rank += 1;
            }

            log.info("유저 포인트 등록이 완료되었습니다.");
        }
    }

}
