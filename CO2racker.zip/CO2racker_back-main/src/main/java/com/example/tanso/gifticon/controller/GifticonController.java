package com.example.tanso.gifticon.controller;

import com.example.tanso.gifticon.service.GifticonService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@Api(tags = {"[App] 기프티콘 API"})
@RestController
@RequestMapping("/gifticon")
@RequiredArgsConstructor
public class GifticonController {

    private final GifticonService gifticonService;

    @PostMapping("")
    @ApiOperation(value = "기프티콘 구매 API/포인트 전환 API", notes = "해당 유저의 5000포인트를 차감하여 기프티콘을 구매한다.\n기프티콘을 구매하는 즉시 현재 유저의 포인트에서 차감되며, 포인트가 부족할 경우 400 예외를 반환한다.")
    @ResponseStatus(HttpStatus.CREATED)
    @ApiResponses({
            @ApiResponse(code = 201, message = "구매 성공"),
            @ApiResponse(code = 400, message = "구매 실패 - 포인트 부족")
    })
    public ResponseEntity<Boolean> purchaseGifticon(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String authorization
    ) throws Exception {
        return new ResponseEntity<>(gifticonService.purchaseGifticon(), HttpStatus.CREATED);
    }

}
