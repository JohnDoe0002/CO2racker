//
//  GifticonRepository.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

final class GifticonRepository: GifticonRepositoryProtocol {
    
    func buyGifticon(authorization: String) -> Single<Void> {
        NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.gifticon.url,
            method: .POST,
            headers: Co2rackerNetworkAPI.headers(authorization: authorization),
            parameters: nil)
        .map{ (responseDTO: GifticonResponseDTO) in }
    }
    
}
