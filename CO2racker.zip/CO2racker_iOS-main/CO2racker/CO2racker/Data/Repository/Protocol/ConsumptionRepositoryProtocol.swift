//
//  ConsumptionRepositoryProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/15.
//

import Foundation
import RxSwift

protocol ConsumptionRepositoryProtocol {
    func fetchConsumptionData(authorization: String, energyType: EnergyType) -> Single<Consumption>
    func fetchConsumptionRanking(authorization: String, energyType: EnergyType) -> Single<[RankInfo]>
    func fetchCO2(authorization: String) -> Single<Double>
}
