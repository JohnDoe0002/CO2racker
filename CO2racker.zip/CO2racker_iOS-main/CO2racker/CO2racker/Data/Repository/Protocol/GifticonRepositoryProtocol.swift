//
//  GifticonRepositoryProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

protocol GifticonRepositoryProtocol {
    func buyGifticon(authorization: String) -> Single<Void>
}
