//
//  UserRepositoryProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/25.
//

import Foundation
import RxSwift

protocol UserRepositoryProtocol {
    func fetchUserInfo(authorization: String) -> Single<User>
    func updateUser(authorization: String, userEditInfo: UserEditInfo) -> Single<Void>
}
