//
//  AuthRepositoryProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/08.
//

import Foundation
import RxSwift

protocol AuthRepositoryProtocol {
    func signUp(signUpInfo: SignUpInfo) -> Single<Void>
    func logIn(loginInfo: LoginInfo) -> Single<String>
    func signOut(authorization: String) -> Single<Void>
    func withdrawal(authorization: String) -> Single<Void>
}
