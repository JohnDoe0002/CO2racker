//
//  AuthRepository.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/08.
//

import Foundation
import RxSwift

final class AuthRepository: AuthRepositoryProtocol {

    private let disposeBag = DisposeBag()
    
    func signUp(signUpInfo: SignUpInfo) -> Single<Void> {
        let dto = SignUpRequestDTO(signUpInfo: signUpInfo)
        
        return NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.signUp.url,
            method: .POST,
            headers: Co2rackerNetworkAPI.headers(),
            parameters: .body(dto)
        )
        .map{ (_: SignUpResponseDTO) in }
    }
    
    func logIn(loginInfo: LoginInfo) -> Single<String> {
        let dto = LoginRequestDTO(loginInfo: loginInfo)

        return NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.signIn.url,
            method: .POST,
            headers: Co2rackerNetworkAPI.headers(),
            parameters: .body(dto)
        )
        .map { (dto: LoginResponseDTO) in
            dto.data.accessToken
        }
    }
    
    func signOut(authorization: String) -> Single<Void> {
        NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.signOut.url,
            method: .POST,
            headers: Co2rackerNetworkAPI.headers(authorization: authorization),
            parameters: nil
        )
        .map { (_: SignOutResponseDTO) in }
    }
    
    func withdrawal(authorization: String) -> Single<Void> {
        NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.withdrawal.url,
            method: .DELETE,
            headers: Co2rackerNetworkAPI.headers(authorization: authorization),
            parameters: nil
        )
        .map { (_: WithdrawalResponseDTO) in }
    }
}
