//
//  UserRepository.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/25.
//

import Foundation
import RxSwift

final class UserRepository: UserRepositoryProtocol {
    
    private let disposeBag = DisposeBag()
    
    func fetchUserInfo(authorization: String) -> Single<User> {
        NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.userInfo.url,
            method: .GET,
            headers: Co2rackerNetworkAPI.headers(authorization: authorization),
            parameters: nil
        ).map { (responseDTO: UserResponseDTO) in
            responseDTO.data.toDomain()
        }
    }
    
    func updateUser(authorization: String, userEditInfo: UserEditInfo) -> Single<Void> {
        let dto = UserEditInfoDTO(userEditInfo)
        return NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.updateUser.url,
            method: .PATCH,
            headers: Co2rackerNetworkAPI.headers(authorization: authorization),
            parameters: .body(dto)
        ).map { (responseDTO: UpdateUserResponseDTO) in }
    }
}
