//
//  ConsumptionRepository.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/15.
//

import Foundation
import RxSwift

enum ConsumptionRepositoryError: Error {
    case notExistSelf
    case notExistData
}

final class ConsumptionRepository: ConsumptionRepositoryProtocol {
    
    private let disposeBag = DisposeBag()
    
    func fetchConsumptionData(authorization: String, energyType: EnergyType) -> Single<Consumption> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(ConsumptionRepositoryError.notExistSelf))
                return Disposables.create()
            }
            
            NetworkManager.shared.request(
                urlString: Co2rackerNetworkAPI.consumption.url,
                method: .GET,
                headers: Co2rackerNetworkAPI.headers(authorization: authorization),
                parameters: .query(["type": energyType.queryString])
            )
            .subscribe(onSuccess: { (response: ConsumptionResponseDTO) in
                single(.success(response.data.toDomain()))
            }, onFailure: { error in
                if let error = error as? NetworkError,
                   case let .invalidStatusCodeError((statusCode, _)) = error,
                   statusCode == 404 {
                    single(.failure(ConsumptionRepositoryError.notExistData))
                }
                single(.failure(error))
            })
            .disposed(by: self.disposeBag)
            
            return Disposables.create()
        }
    }
    
    func fetchConsumptionRanking(authorization: String, energyType: EnergyType) -> Single<[RankInfo]> {
        NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.consumptionRanking.url,
            method: .GET,
            headers: Co2rackerNetworkAPI.headers(authorization: authorization),
            parameters: .query(["type": energyType.queryString])
        )
        .map { (response: RankingResponseDTO) in
            response.data.map { $0.toDomain() }
        }
    }
    
    func fetchCO2(authorization: String) -> Single<Double> {
        NetworkManager.shared.request(
            urlString: Co2rackerNetworkAPI.co2.url,
            method: .GET,
            headers: Co2rackerNetworkAPI.headers(authorization: authorization),
            parameters: nil
        )
        .map { (response: CO2ResponseDTO) in
            response.data.totalCo2
        }
    }
}
