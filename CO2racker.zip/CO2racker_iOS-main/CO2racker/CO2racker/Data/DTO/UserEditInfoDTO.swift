//
//  UserEditInfoDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation

struct UserEditInfoDTO: Encodable {
    let nickname: String
    let password: String
    let roadnameAddress: String
    let detailAddress: String
    
    enum CodingKeys: String, CodingKey {
        case nickname, password
        case roadnameAddress = "addr"
        case detailAddress = "detailAddr"
    }
    
    init(nickname: String, password: String, roadnameAddress: String, detailAddress: String) {
        self.nickname = nickname
        self.password = password
        self.roadnameAddress = roadnameAddress
        self.detailAddress = detailAddress
    }
    
    init(_ editInfo: UserEditInfo) {
        self.init(
            nickname: editInfo.nickname,
            password: editInfo.password,
            roadnameAddress: editInfo.roadnameAddress,
            detailAddress: editInfo.detailAddress
        )
    }
}
