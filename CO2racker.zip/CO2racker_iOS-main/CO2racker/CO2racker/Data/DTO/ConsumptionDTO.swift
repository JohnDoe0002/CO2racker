//
//  ConsumptionDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/16.
//

import Foundation

struct ConsumptionResponseDTO: Decodable {
    let data: ConsumptionDTO
}

// MARK: - ConsumptionDTO
struct ConsumptionDTO: Decodable {
    let seq, userID: Int
    let nickname, area, type: String
    let consumption, rank, rankAgainstPrevMonth, totalHouseholds: Int
    let consumptionGraphData: [ConsumptionGraphDatumDTO]
    let createdAt, updatedAt: String
    let status: Int

    enum CodingKeys: String, CodingKey {
        case seq
        case userID = "userId"
        case consumption = "consumed"
        case consumptionGraphData = "todayConsumedGraphData"
        case nickname, area, type, rank, rankAgainstPrevMonth, totalHouseholds, createdAt, updatedAt, status
    }
    
    func toDomain() -> Consumption {
        Consumption(
            type: EnergyType(rawValue: type) ?? .power,
            consumption: consumption,
            rank: rank,
            rankAgainstPrevMonth: rankAgainstPrevMonth,
            area: area,
            totalHouseholds: totalHouseholds,
            consumptionGraphData: consumptionGraphData.map { $0.toDomain() },
            updatedAt: updatedAt.toDate() ?? Date()
        )
    }
}

// MARK: - TodayConsumedGraphDatum
struct ConsumptionGraphDatumDTO: Decodable {
    let createdAt: String
    let consumption: Int
    
    enum CodingKeys: String, CodingKey {
        case consumption = "consumed"
        case createdAt
    }
    
    func toDomain() -> ConsumptionGraphDatum {
        ConsumptionGraphDatum(createdAt: createdAt, consumption: consumption)
    }
}
