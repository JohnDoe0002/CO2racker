//
//  UserDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/23.
//

import Foundation

struct UserResponseDTO: Decodable {
    let success: Bool
    let status: Int
    let message: String
    let data: UserDTO
}

struct UserDTO: Decodable {
    let id: Int
    let userID: String
    let nickname: String
    let address, detailAddress: String
    let point, gifticonCount: Int
    let accountNonExpired, accountNonLocked, credentialsNonExpired, enabled: Bool
    
    enum CodingKeys: String, CodingKey {
        case id
        case userID = "username"
        case nickname
        case address = "addr"
        case detailAddress = "detailAddr"
        case point
        case gifticonCount = "gifticonCounts"
        case accountNonExpired, accountNonLocked, credentialsNonExpired, enabled
    }
    
    func toDomain() -> User {
        User(
            userID: userID,
            nickName: nickname,
            address: address,
            detailAddress: detailAddress,
            point: point,
            gifticonCount: gifticonCount
        )
    }
}
