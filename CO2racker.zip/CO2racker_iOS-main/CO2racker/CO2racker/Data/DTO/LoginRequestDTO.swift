//
//  LoginRequestDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation

struct LoginRequestDTO: Encodable {
    let userID: String
    let password: String
    
    enum CodingKeys: String, CodingKey {
        case userID = "username"
        case password
    }
    
    init(userID: String, password: String) {
        self.userID = userID
        self.password = password
    }
    
    init(loginInfo: LoginInfo) {
        self.init(
            userID: loginInfo.userID,
            password: loginInfo.password
        )
    }
}
