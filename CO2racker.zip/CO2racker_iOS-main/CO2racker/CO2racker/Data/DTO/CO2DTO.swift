//
//  CO2DTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/21.
//

import Foundation

struct CO2ResponseDTO: Decodable {
    let success: Bool
    let status: Int
    let message: String
    let data: CO2DTO
}

struct CO2DTO: Decodable {
    let totalCo2: Double
}
