//
//  LoginResponseDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation

struct LoginResponseDTO: Decodable {
    let success: Bool
    let status: Int
    let message: String
    let data: LoginDTO
}

struct LoginDTO: Decodable {
    let userID: Int
    let accessToken: String

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case accessToken
    }
}
