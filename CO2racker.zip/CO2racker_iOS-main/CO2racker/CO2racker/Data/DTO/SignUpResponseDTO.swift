//
//  SignUpResponseDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation

struct SignUpResponseDTO: Decodable {
    let success: Bool
    let status: Int
    let message: String
    let data: SignUpDTO
}

struct SignUpDTO: Decodable {
    let id: Int
    let username, nickname, addr, detailAddr: String
    let point, gifticonCounts: Int
    let enabled, accountNonLocked, accountNonExpired, credentialsNonExpired: Bool
}
