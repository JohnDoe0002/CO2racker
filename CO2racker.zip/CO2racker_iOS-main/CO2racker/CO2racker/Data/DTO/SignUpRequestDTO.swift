//
//  SignUpRequestDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/08.
//

import Foundation

struct SignUpRequestDTO: Encodable {
    let userID: String
    let password: String
    let nickName: String
    let address: String
    let detailAddress: String
    
    enum CodingKeys: String, CodingKey {
        case userID = "username"
        case password
        case nickName = "nickname"
        case address = "addr"
        case detailAddress = "detailAddr"
    }
    
    init(userID: String, password: String, nickName: String, address: String, detailAddress: String) {
        self.userID = userID
        self.password = password
        self.nickName = nickName
        self.address = address
        self.detailAddress = detailAddress
    }
    
    init(signUpInfo: SignUpInfo) {
        self.init(
            userID: signUpInfo.userID,
            password: signUpInfo.password,
            nickName: signUpInfo.nickName,
            address: signUpInfo.address,
            detailAddress: signUpInfo.detailAddress
        )
    }
}

/*
 {
   "addr": "미추홀구",
   "detailAddr": "인하대학교",
   "nickname": "12191613",
   "password": "1111",
   "username": "상연"
 }
 */
