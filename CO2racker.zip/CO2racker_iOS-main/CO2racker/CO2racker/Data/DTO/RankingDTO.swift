//
//  RankingDTO.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import Foundation

// MARK: - RankingResponseDTO
struct RankingResponseDTO: Decodable {
    let data: [RankingDTO]
}

// MARK: - Datum
struct RankingDTO: Decodable {
    let userID, rank: Int
    let type, nickname: String
    let consumption: Int

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case rank, type, nickname
        case consumption = "consumed"
    }
    
    func toDomain() -> RankInfo {
        RankInfo(
            type: EnergyType(rawValue: type) ?? .power,
            rank: rank,
            nickname: nickname,
            consumption: consumption
        )
    }
}
