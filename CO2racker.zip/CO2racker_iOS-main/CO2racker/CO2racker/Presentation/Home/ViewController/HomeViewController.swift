//
//  MainViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import UIKit
import SnapKit
import RxSwift

final class HomeViewController: UIViewController {
    
    // MARK: - UI properties
    
    struct UIConstants {
        static let cellSpacing = 15
        static let cellHeight = 120
        static let inset = 15
    }
    
    private let scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()
    private let contentView = UIView()
    
    private var collectionView: UICollectionView!
    private let dateAndAreaLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = .systemGray1
        label.text = "dateAndAreaLabel"
        label.textAlignment = .right
        return label
    }()
    private let carbonFootPrintView = CarbonFootPrintView()
    
    // MARK: - Properties
    
    private let viewModel: HomeViewModel
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(viewModel: HomeViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureCollectionView()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func configureCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(view.frame.width - CGFloat(UIConstants.inset*2)),
            height: CGFloat(UIConstants.cellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.cellSpacing)
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        collectionView.register(HomeCollectionViewCell.self, forCellWithReuseIdentifier: HomeCollectionViewCell.identifier)
        collectionView.isScrollEnabled = false
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        contentView.addSubview(collectionView)
        contentView.addSubview(dateAndAreaLabel)
        contentView.addSubview(carbonFootPrintView)
        
        configureUI()
    }
    
    private func configureUI() {
        scrollView.snp.makeConstraints {
            $0.top.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
        contentView.snp.makeConstraints {
            $0.top.leading.trailing.bottom.equalToSuperview()
            $0.width.equalToSuperview()
        }
        
        collectionView.snp.makeConstraints {
            $0.top.leading.trailing.equalToSuperview().inset(UIConstants.inset)
            $0.height.equalTo(300)
        }
        dateAndAreaLabel.snp.makeConstraints {
            $0.top.equalTo(collectionView.snp.bottom).offset(7)
            $0.trailing.equalTo(collectionView)
            $0.height.equalTo(18)
            $0.width.equalTo(300)
        }
        carbonFootPrintView.snp.makeConstraints {
            $0.top.equalTo(dateAndAreaLabel.snp.bottom).offset(10)
            $0.leading.trailing.equalToSuperview().inset(UIConstants.inset)
            $0.height.equalTo(220)
            $0.bottom.equalToSuperview()
        }
    }
    
    private func bind() {
        let input = HomeViewModel.Input(
            viewWillAppear: rx.methodInvoked(#selector(viewWillAppear(_:))).map{ _ in }.asObservable()
        )
        let output = viewModel.transform(input)
        
        output.consumptionData
            .do(onNext: { [weak self] data in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.collectionView.snp.updateConstraints{
                        var height = UIConstants.cellHeight * data.count + UIConstants.cellSpacing * (data.count-1) + 3
                        if data.isEmpty { height = 0 }
                        $0.height.equalTo(height)
                    }
                }
            })
            .bind(to: collectionView.rx.items(
                cellIdentifier: HomeCollectionViewCell.identifier,
                cellType: HomeCollectionViewCell.self
            )) { (_, item, cell) in
                cell.bind(consumption: item)
            }
            .disposed(by: disposeBag)
        
        output.dateAndArea
            .subscribe(onNext: { [weak self] text in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.dateAndAreaLabel.text = text
                }
            })
            .disposed(by: disposeBag)
        
        output.carbonUsage
            .subscribe(onNext: { [weak self] usage in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.carbonFootPrintView.bind(carbonUsage: usage)
                }
            })
            .disposed(by: disposeBag)
    }
}
