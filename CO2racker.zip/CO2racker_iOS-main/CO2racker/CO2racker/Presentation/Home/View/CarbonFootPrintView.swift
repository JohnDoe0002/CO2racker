//
//  CarbonFootPrintView.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/21.
//

import UIKit
import SnapKit

final class CarbonFootPrintView: UIView {
    // MARK: - UI properties
    struct UIConstants {
        static let circleSize = 180.0
    }
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.text = "탄소 발자국"
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        return label
    }()
    
    private let circleView: UIView = {
        let view = UIView()
        view.backgroundColor = .mainColor
        view.layer.cornerRadius = UIConstants.circleSize / 2
        return view
    }()
    
    private let carbonLabel: UILabel = {
        let label = UILabel()
        label.text = "CO₂ 배출량"
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 26)
        label.textAlignment = .center
        return label
    }()
    
    private let usageLabel: UILabel = {
        let label = UILabel()
        label.text = "0.0kg"
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 26)
        label.textAlignment = .center
        return label
    }()
    
    // MARK: - Lifecycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
    }
    
    // MARK: - Helpers
    private func setupViews() {
        addSubview(titleLabel)
        addSubview(circleView)
        circleView.addSubview(carbonLabel)
        circleView.addSubview(usageLabel)
        
        configureUI()
    }
    
    private func configureUI() {
        titleLabel.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.trailing.equalToSuperview().inset(3)
            $0.height.equalTo(22)
        }
        circleView.snp.makeConstraints {
            $0.top.equalTo(titleLabel.snp.bottom).offset(5)
            $0.centerX.equalToSuperview()
            $0.width.height.equalTo(UIConstants.circleSize)
        }
        carbonLabel.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.centerY.equalToSuperview().offset(-15)
            $0.width.equalTo(140)
            $0.height.equalTo(35)
        }
        usageLabel.snp.makeConstraints {
            $0.centerX.equalToSuperview()
            $0.centerY.equalToSuperview().offset(15)
            $0.width.equalTo(140)
            $0.height.equalTo(35)
        }
    }
    
    func bind(carbonUsage: Double) {
        usageLabel.text = "\(carbonUsage)kg"
    }
}
