//
//  MainCollectionViewCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import UIKit

final class HomeCollectionViewCell: UICollectionViewCell {
    
    // MARK: - Properties
    
    static let identifier = "HomeCollectionViewCell"
    
    // MARK: - UI Properties
    
    private let titleLabel: UILabel = {
        var label = UILabel()
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.text = "타이틀"
        return label
    }()
    
    private let contentsView: UIView = {
        var view = UIView()
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.mainColor.cgColor
        view.layer.cornerRadius = 10
        view.backgroundColor = .white
        return view
    }()
    
    private let usageLabel = TitleAndValueLabel(title: "사용량")
    private let rankingLabel = TitleAndValueLabel(title: "랭킹")
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Helpers
    
    private func setupViews() {
        addSubview(titleLabel)
        addSubview(contentsView)
        contentsView.addSubview(usageLabel)
        contentsView.addSubview(rankingLabel)
        configureUI()
        
        contentsView.addShadow(offset: CGSize(width: 0, height: 2))
    }
    
    private func configureUI() {
        titleLabel.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.equalToSuperview().inset(3)
            $0.height.equalTo(20)
        }
        contentsView.snp.makeConstraints {
            $0.top.equalTo(titleLabel.snp.bottom).offset(5)
            $0.leading.trailing.equalToSuperview()
            $0.height.equalTo(95)
        }
        
        usageLabel.snp.makeConstraints {
            $0.top.leading.trailing.equalToSuperview().inset(20)
            $0.height.equalTo(22)
        }
        rankingLabel.snp.makeConstraints {
            $0.top.equalTo(usageLabel.snp.bottom).offset(10)
            $0.leading.trailing.height.equalTo(usageLabel)
        }
    }
    
    func bind(consumption: Consumption) {
        titleLabel.text = consumption.type.title
        if consumption.consumption != -1 {
            usageLabel.bind(value: "\(consumption.consumption) \(consumption.type.unit)")
            
            let rankString = consumption.rankAgainstPrevMonth == -1 ? "기록 없음" : "\(consumption.rankAgainstPrevMonth)위"
            rankingLabel.bind(value: rankString)
        } else {
            usageLabel.bind(value: "기록 없음")
            rankingLabel.bind(value: "기록 없음")
        }
    }
}

