//
//  MainViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/04.
//

import Foundation
import RxSwift

final class HomeViewModel {
    
    // MARK: - Input
    
    struct Input {
        let viewWillAppear: Observable<Void>
    }
    
    // MARK: - Output
    
    struct Output {
        var consumptionData = BehaviorSubject<[Consumption]>(value: [])
        var dateAndArea = BehaviorSubject<String>(value: "")
        var carbonUsage = BehaviorSubject<Double>(value: 0)
    }
    
    // MARK: - Properties
    
    let showIndicator = PublishSubject<Bool>()
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependency
    
    private let usecase: HomeUseCaseProtocol
    
    // MARK: - Lifecycles
    
    init(usecase: HomeUseCaseProtocol) {
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        input.viewWillAppear
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let accessToken = UserDefaults.accessToken else { return }
                
                showIndicator.onNext(true)
                
                Single.zip(
                    usecase.fetchConsumptionData(authorization: accessToken),
                    usecase.fetchUserArea(authorization: accessToken),
                    usecase.fetchCO2(authorization: accessToken)
                )
                .subscribe(onSuccess: { [weak self] (consumptionArray, area, co2) in
                    guard let self else { return }
                    output.consumptionData.onNext(consumptionArray)
                    
                    let dateAndAreaString = fetchDateAndArea(consumptions: consumptionArray, area: area)
                    output.dateAndArea.onNext(dateAndAreaString)
                    
                    output.carbonUsage.onNext(co2)
                    
                    showIndicator.onNext(false)
                }, onFailure: { error in
                    print(error)
                })
                .disposed(by: self.disposeBag)
                
            })
            .disposed(by: disposeBag)
        
        return output
    }
    
    private func fetchDateAndArea(consumptions: [Consumption], area: String) -> String {
        guard let consumption = consumptions.first(where: { $0.consumption != -1 }) else {
            let dateString = Date().toString()
            return dateString + ", \(area) 기준"
        }
        let dateString = consumption.updatedAt.toString()
        return dateString + ", \(consumption.area) 기준"
    }
}
