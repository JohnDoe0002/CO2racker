//
//  SignUpViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import Foundation
import RxSwift

final class SignUpViewModel {
    
    // MARK: - Input
    
    struct Input {
        let emailDidChanged: BehaviorSubject<String>
        let passwordDidChanged: BehaviorSubject<String>
        let nicknameDidChanged: BehaviorSubject<String>
        let roadNameAddressDidChanged: BehaviorSubject<String>
        let detailAddressDidChanged: BehaviorSubject<String>
        let addressSearchButtonDidTapped: Observable<Void>
        let signUpButtonDidTapped: Observable<Void>
    }
    
    // MARK: - Output
    
    struct Output {
        let inputIsValid = BehaviorSubject<Bool>(value: false)
        let roadnameAddress = PublishSubject<String>()
    }
    
    // MARK: - Properties
    
    let showLoginViewController = PublishSubject<Void>()
    let showPostCodeWebView = PublishSubject<PublishSubject<String>>()
    let showAlert = PublishSubject<AlertMessageType>()
    let showIndicator = PublishSubject<Bool>()
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependencies
    
    private let usecase: SignUpUseCaseProtocol
    
    // MARK: - LifeCycles
    
    init(usecase: SignUpUseCaseProtocol) {
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        Observable.combineLatest(input.emailDidChanged, input.passwordDidChanged, input.nicknameDidChanged, input.roadNameAddressDidChanged)
            .subscribe(onNext: { [weak self] (email, password, nickname, roadNameAddress) in
                guard let self else { return }
                let isValid = usecase.isValid(email, password, nickname, roadNameAddress)
                output.inputIsValid.onNext(isValid)
            })
            .disposed(by: disposeBag)
        
        input.addressSearchButtonDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showPostCodeWebView.onNext(output.roadnameAddress)
            })
            .disposed(by: disposeBag)
        
        input.signUpButtonDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let email = try? input.emailDidChanged.value(),
                      let password = try? input.passwordDidChanged.value(),
                      let nickname = try? input.nicknameDidChanged.value(),
                      let roadNameAddress = try? input.roadNameAddressDidChanged.value() else {
                    return
                }
                let detailAddress = (try? input.detailAddressDidChanged.value()) ?? ""
                
                let signUpInfo = SignUpInfo(
                    userID: email,
                    password: password,
                    nickName: nickname,
                    address: roadNameAddress,
                    detailAddress: detailAddress
                )
                
                showIndicator.onNext(true)
                signUp(signUpInfo)
            })
            .disposed(by: disposeBag)
        
        return output
    }
    
    private func signUp(_ signUpInfo: SignUpInfo) {
        usecase.signUp(signUpInfo)
            .subscribe(onSuccess: { _ in
                DispatchQueue.main.async {
                    self.showIndicator.onNext(false)
                    self.showLoginViewController.onNext(())
                }
            }, onFailure: { error in
                DispatchQueue.main.async {
                    self.showIndicator.onNext(false)
                    self.showAlert.onNext(.signUpFailure(error: error))
                }
            })
            .disposed(by: disposeBag)
    }
}
