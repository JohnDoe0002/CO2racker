//
//  SignUpBasicInfoViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/03/27.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa

final class SignUpViewController: UIViewController {
    
    // MARK: - UI properties
    
    private var basicInfoCollectionView: UICollectionView!
    
    private let roadNameAddressTextfield = CommonTextfieldCell(
        title: AuthTextfieldType.roadnameAddress.title,
        placeholder: AuthTextfieldType.roadnameAddress.placeholder
    )
    
    private let addressSearchButton = MainColorButton(title: "검색")
    
    private let detailedAddressTextfield = CommonTextfieldCell(
        title: AuthTextfieldType.detailedAddress.title,
        placeholder: AuthTextfieldType.detailedAddress.placeholder
    )
    
    private let signUpButton = MainColorButton(title: "회원가입")
    
    struct UIConstants {
        static let cellSpacing = 24
        static let cellHeight = 70
        static let buttonHeight = 45
        static let inset = 15
        static let searchButtonWidth = 60
    }
    
    // MARK: - Properties
    
    private let numberOfItems = 3
    
    private let emailTextFieldChanged = BehaviorSubject<String>(value: "")
    private let passwordTextFieldChanged = BehaviorSubject<String>(value: "")
    private let nicknameTextFieldChanged = BehaviorSubject<String>(value: "")
    private let roadNameAddressTextFieldChanged = BehaviorSubject<String>(value: "")
    private let detailAddressTextFieldChanged = BehaviorSubject<String>(value: "")
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependencies
    private let viewModel: SignUpViewModel
    
    // MARK: - Lifecycles
    init(viewModel: SignUpViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureCollectionView()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func configureCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(view.frame.width - CGFloat(UIConstants.inset*2)),
            height: CGFloat(UIConstants.cellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.cellSpacing)
        basicInfoCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        basicInfoCollectionView.dataSource = self
        basicInfoCollectionView.register(CommonTextfieldCell.self, forCellWithReuseIdentifier: CommonTextfieldCell.identifier)
        basicInfoCollectionView.isScrollEnabled = false
    }
    
    private func setupViews() {
        title = "회원가입"
        view.backgroundColor = .white
        setupBackButton()
        
        view.addSubview(basicInfoCollectionView)
        view.addSubview(roadNameAddressTextfield)
        view.addSubview(addressSearchButton)
        view.addSubview(detailedAddressTextfield)
        view.addSubview(signUpButton)
        
        configureUI()
    }
    
    private func configureUI() {
        basicInfoCollectionView.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset)
            $0.leading.trailing.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset)
            let height = numberOfItems * UIConstants.cellHeight + UIConstants.cellSpacing * (numberOfItems-1)
            $0.height.equalTo(height)
        }
        roadNameAddressTextfield.snp.makeConstraints {
            $0.top.equalTo(basicInfoCollectionView.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.equalTo(basicInfoCollectionView)
            $0.trailing.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset * 2 + UIConstants.searchButtonWidth)
            $0.height.equalTo(UIConstants.cellHeight)
        }
        addressSearchButton.snp.makeConstraints {
            $0.bottom.equalTo(roadNameAddressTextfield)
            $0.height.equalTo(UIConstants.buttonHeight)
            $0.leading.equalTo(roadNameAddressTextfield.snp.trailing).offset(UIConstants.inset)
            $0.trailing.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset)
        }
        detailedAddressTextfield.snp.makeConstraints {
            $0.top.equalTo(roadNameAddressTextfield.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.height.equalTo(roadNameAddressTextfield)
            $0.trailing.equalTo(addressSearchButton)
        }
        signUpButton.snp.makeConstraints {
            $0.top.equalTo(detailedAddressTextfield.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.equalTo(detailedAddressTextfield)
            $0.height.equalTo(UIConstants.buttonHeight)
        }
    }
    
    private func bind() {
        let input = SignUpViewModel.Input(
            emailDidChanged: emailTextFieldChanged,
            passwordDidChanged: passwordTextFieldChanged,
            nicknameDidChanged: nicknameTextFieldChanged,
            roadNameAddressDidChanged: roadNameAddressTextFieldChanged,
            detailAddressDidChanged: detailAddressTextFieldChanged,
            addressSearchButtonDidTapped: addressSearchButton.rx.tap.asObservable(), 
            signUpButtonDidTapped: signUpButton.rx.tap.asObservable()
        )
        let output = viewModel.transform(input)
        
        bindTextfield()
        
        output.inputIsValid
            .subscribe(onNext: { [weak self] isValid in
                guard let self else { return }
                signUpButton.isEnabled = isValid
            })
            .disposed(by: disposeBag)
        
        output.roadnameAddress
            .subscribe(onNext: { [weak self] address in
                guard let self else { return }
                roadNameAddressTextfield.bind(content: address)
            })
            .disposed(by: disposeBag)
    }
    
    private func bindTextfield() {
        roadNameAddressTextfield.textfield.rx.text.orEmpty.asObservable()
            .bind(to: roadNameAddressTextFieldChanged)
            .disposed(by: disposeBag)
        
        // textfield.text = "" 같은 변화 있을 때 이벤트 발생
        roadNameAddressTextfield.textfield.rx.observe(String.self, "text")
            .map{ $0 ?? "" }
            .bind(to: roadNameAddressTextFieldChanged)
            .disposed(by: disposeBag)
        
        detailedAddressTextfield.textfield.rx.text.orEmpty.asObservable()
            .bind(to: detailAddressTextFieldChanged)
            .disposed(by: disposeBag)
    }
}

extension SignUpViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return numberOfItems
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: CommonTextfieldCell.identifier,
            for: indexPath
        ) as? CommonTextfieldCell,
              let textfieldType = AuthTextfieldType(rawValue: indexPath.row) else {
            return CommonTextfieldCell()
        }
        
        cell.bind(title: textfieldType.title, placeholder: textfieldType.placeholder)
        
        switch textfieldType {
        case .email:
            cell.textfield.rx.text.orEmpty.asObservable()
                .bind(to: emailTextFieldChanged)
                .disposed(by: cell.disposeBag)
        case .password:
            cell.setTextFieldForPassword()
            cell.textfield.rx.text.orEmpty.asObservable()
                .bind(to: passwordTextFieldChanged)
                .disposed(by: cell.disposeBag)
        case .nickname:
            cell.textfield.rx.text.orEmpty.asObservable()
                .bind(to: nicknameTextFieldChanged)
                .disposed(by: cell.disposeBag)
        default:
            break
        }
        
        return cell
    }
    
}
