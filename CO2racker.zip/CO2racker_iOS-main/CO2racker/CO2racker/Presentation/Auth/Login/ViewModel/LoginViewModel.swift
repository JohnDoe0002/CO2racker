//
//  LoginViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import Foundation
import RxSwift

final class LoginViewModel {
    
    // MARK: - Input
    
    struct Input {
        let emailDidChanged: BehaviorSubject<String>
        let passwordDidChanged: BehaviorSubject<String>
        let loginButtonDidTapped: Observable<Void>
        let signUpButtonDidTapped: Observable<Void>
    }
    
    // MARK: - Output
    struct Output {
        let inputIsValid = BehaviorSubject<Bool>(value: false)
    }
    
    // MARK: - Properties
    let showSignUpViewController = PublishSubject<Void>()
    let startMainFlow = PublishSubject<Void>()
    let showAlert = PublishSubject<AlertMessageType>()
    let showIndicator = PublishSubject<Bool>()
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependency
    private let usecase: LoginUseCaseProtocol

    // MARK: - Lifecycles
    init(usecase: LoginUseCaseProtocol) {
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        Observable.combineLatest(input.emailDidChanged, input.passwordDidChanged)
            .subscribe(onNext: { [weak self] email, password in
                guard let self else { return }
                let isValid = usecase.isValid(email, password)
                output.inputIsValid.onNext(isValid)
            })
            .disposed(by: disposeBag)
        
        input.loginButtonDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let email = try? input.emailDidChanged.value(),
                      let password = try? input.passwordDidChanged.value() else {
                    return
                }
                showIndicator.onNext(true)
                login(email, password)
            })
            .disposed(by: disposeBag)
        
        input.signUpButtonDidTapped
            .bind(to: showSignUpViewController)
            .disposed(by: disposeBag)
        
        return output
    }
    
    private func login(_ email: String, _ password: String) {
        usecase.login(email, password)
            .subscribe(onSuccess: {
                DispatchQueue.main.async {
                    self.showIndicator.onNext(false)
                    self.startMainFlow.onNext(())
                }
            }, onFailure: { error in
                DispatchQueue.main.async {
                    self.showIndicator.onNext(false)
                    self.showAlert.onNext(.loginFailure(error: error))
                }
            })
            .disposed(by: disposeBag)
    }

}
