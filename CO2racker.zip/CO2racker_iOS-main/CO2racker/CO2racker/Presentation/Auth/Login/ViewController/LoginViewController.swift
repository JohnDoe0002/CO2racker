//
//  LoginViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/03/28.
//

import UIKit
import RxSwift
import RxCocoa

final class LoginViewController: UIViewController {

    // MARK: - UI properties
    
    private var collectionView: UICollectionView!
    private let loginButton = MainColorButton(title: "로그인")
    private let signUpButton = MainColorButton(title: "회원가입")
            
    // MARK: - Properties
    
    private let numberOfItems = 2
    
    struct UIConstants {
        static let cellSpacing = 24
        static let cellHeight = 70
        static let textFieldHeight = 45
        static let inset = 15
    }
    
    private let emailTextFieldChanged = BehaviorSubject<String>(value: "")
    private let passwordTextFieldChanged = BehaviorSubject<String>(value: "")
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependencies
    private let viewModel: LoginViewModel
    
    // MARK: - Lifecycles
    
    init(viewModel: LoginViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureCollectionView()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func configureCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(view.frame.width - CGFloat(UIConstants.inset*2)),
            height: CGFloat(UIConstants.cellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.cellSpacing)
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        collectionView.dataSource = self
        collectionView.register(CommonTextfieldCell.self, forCellWithReuseIdentifier: CommonTextfieldCell.identifier)
        collectionView.isScrollEnabled = false
    }
    
    private func setupViews() {
        title = "로그인"
        view.backgroundColor = .white
        setupBackButton()
        
        view.addSubview(collectionView)
        collectionView.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset)
            $0.leading.trailing.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset)
            let height = numberOfItems * UIConstants.cellHeight + UIConstants.cellSpacing * (numberOfItems-1)
            $0.height.equalTo(height)
        }
        
        view.addSubview(loginButton)
        loginButton.snp.makeConstraints {
            $0.top.equalTo(collectionView.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.equalTo(collectionView)
            $0.height.equalTo(UIConstants.textFieldHeight)
        }
        
        view.addSubview(signUpButton)
        signUpButton.snp.makeConstraints {
            $0.top.equalTo(loginButton.snp.bottom).offset(UIConstants.inset)
            $0.leading.trailing.height.equalTo(loginButton)
        }
    }
    
    private func bind() {
        let input = LoginViewModel.Input(
            emailDidChanged: emailTextFieldChanged,
            passwordDidChanged: passwordTextFieldChanged,
            loginButtonDidTapped: loginButton.rx.tap.asObservable(),
            signUpButtonDidTapped: signUpButton.rx.tap.asObservable()
        )
        let output = viewModel.transform(input)
        
        output.inputIsValid
            .subscribe(onNext: { [weak self] isValid in
                guard let self else { return }
                loginButton.isEnabled = isValid
            })
            .disposed(by: disposeBag)
    }
}

extension LoginViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return numberOfItems
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: CommonTextfieldCell.identifier,
            for: indexPath
        ) as? CommonTextfieldCell,
              let textfieldType = AuthTextfieldType(rawValue: indexPath.row) else {
            return CommonTextfieldCell()
        }
        
        cell.bind(title: textfieldType.title, placeholder: textfieldType.placeholder)
        
        switch textfieldType {
        case .email:
            cell.textfield.rx.text.orEmpty.asObservable()
                .bind(to: emailTextFieldChanged)
                .disposed(by: cell.disposeBag)
        case .password:
            cell.setTextFieldForPassword()
            cell.textfield.rx.text.orEmpty.asObservable()
                .bind(to: passwordTextFieldChanged)
                .disposed(by: cell.disposeBag)
        default:
            break
        }

        return cell
    }
    
}
