//
//  ConsumptionRankingViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import Foundation
import RxSwift

final class ConsumptionRankingViewModel {
    
    // MARK: - Input
    
    struct Input {
        let viewWillAppear: Observable<Void>
    }
    
    // MARK: - Output
    
    struct Output {
        let top3Ranking = BehaviorSubject<[RankInfo]>(value: [])
        let lowerRanking = BehaviorSubject<[RankInfo]>(value: [])
    }
    
    // MARK: - Properties
    
    let showIndicator = PublishSubject<Bool>()
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependencies
    
    private let energyType: EnergyType
    
    private let usecase: ConsumptionRankingUseCaseProtocol
    
    // MARK: - LifeCycles
    init(energyType: EnergyType, usecase: ConsumptionRankingUseCaseProtocol) {
        self.energyType = energyType
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        input.viewWillAppear
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let accessToken = UserDefaults.accessToken else { return }
                
                showIndicator.onNext(true)
                
                usecase.fetchRanking(
                    authorization: accessToken,
                    energyType: self.energyType
                )
                .subscribe(onSuccess: { [weak self] rankings in
                    guard let self else { return }
                    let count = rankings.count
                    
                    if count < 3 {
                        output.top3Ranking.onNext(self.createEmptyRankInfos(rankings))
                    } else if count == 3 {
                        output.top3Ranking.onNext(rankings)
                    } else {
                        output.top3Ranking.onNext(Array(rankings[0..<3]))
                        output.lowerRanking.onNext(Array(rankings[3..<count]))
                    }
                    
                    showIndicator.onNext(false)
                }, onFailure: { error in
                    print(error)
                })
                .disposed(by: self.disposeBag)
            })
            .disposed(by: disposeBag)
        
        return output
    }
    
    private func createEmptyRankInfos(_ rankings: [RankInfo]) -> [RankInfo] {
        var newRankings = rankings
        while newRankings.count < 3 {
            newRankings.append(RankInfo())
        }
        return newRankings
    }
}
