//
//  AnalysisViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/15.
//

import Foundation
import RxSwift

final class ConsumptionAnalysisViewModel {
    
    // MARK: - Input
    
    struct Input {
        let viewWillAppear: Observable<Void>
    }
    
    // MARK: - Output
    
    struct Output {
        let dataExist = BehaviorSubject<Bool>(value: true)
        let updatedDate = BehaviorSubject<String>(value: "")
        let consumptionAndRanking = BehaviorSubject<[String]>(value: [])
        let areaAndHouseHold = BehaviorSubject<String>(value: "")
        let graphData = BehaviorSubject<(type: EnergyType, items: [ConsumptionGraphItem])>(value: (.power, []))
    }
    
    // MARK: - Properties
    
    let showIndicator = PublishSubject<Bool>()
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependencies
    
    private let energyType: EnergyType
    
    private let usecase: ConsumptionAnalysisUseCaseProtocol
    
    // MARK: - LifeCycles
    init(energyType: EnergyType, usecase: ConsumptionAnalysisUseCaseProtocol) {
        self.energyType = energyType
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        input.viewWillAppear
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let accessToken = UserDefaults.accessToken else { return }
                
                showIndicator.onNext(true)
                
                usecase.fetchConsumptionData(
                    authorization: accessToken,
                    energyType: self.energyType
                )
                .subscribe(onSuccess: { [weak self] consumption in
                    guard let self else { return }
                    guard let consumption else {
                        output.dataExist.onNext(false)
                        showIndicator.onNext(false)
                        return
                    }
                    
                    output.dataExist.onNext(true)
                    
                    output.updatedDate.onNext(consumption.updatedAt.toString() + " 기준")
                    
                    let consumptionAndRanking = configureConsumptionAndRankString(
                        consumption: consumption.consumption,
                        rank: consumption.rank,
                        rankAgainstPrevMonth: consumption.rankAgainstPrevMonth
                    )
                    output.consumptionAndRanking.onNext(consumptionAndRanking)
                    
                    let areaAndHousehold = configureAreaAndHouseholdString(
                        area: consumption.area,
                        household: consumption.totalHouseholds
                    )
                    output.areaAndHouseHold.onNext(areaAndHousehold)
                    
                    let graphData = processGraphData(consumption.consumptionGraphData)
                    output.graphData.onNext((energyType, graphData))
                    
                    showIndicator.onNext(false)
                    
                }, onFailure: { error in
                    print(error)
                })
                .disposed(by: self.disposeBag)
            })
            .disposed(by: disposeBag)
        
        return output
    }
    
    private func configureConsumptionAndRankString(consumption: Int, rank: Int, rankAgainstPrevMonth: Int) -> [String] {
        let consumption = [String(consumption) + self.energyType.unit]
        let rankings = [rank, rankAgainstPrevMonth].map { rank in
            if rank == -1 { return "순위 없음" }
            return String(rank) + "위"
        }
        return consumption + rankings
    }
    
    private func configureAreaAndHouseholdString(area: String, household: Int) -> String {
        area + " 기준, 총 " + String(household) + "가구"
    }
    
    /// 15분 간격 데이터이므로 4개씩 1시간 간격 소비량으로 변환
    private func processGraphData(_ data: [ConsumptionGraphDatum]) -> [ConsumptionGraphItem] {
        var graphData = [ConsumptionGraphItem]()
        var hour = 0
        let repeatCount = data.count / 4
        
        if repeatCount > 0 {
            for i in 0..<repeatCount {
                let dataIndex = 4*(i+1) - 1
                graphData.append(.init(amount: data[dataIndex].consumption, hour: hour))
                hour += 1
            }
        }
        if data.count % 4 != 0 {
            graphData.append(.init(amount: data[data.count-1].consumption, hour: hour))
        }
            
        return graphData
    }
}
