//
//  AnalysisViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/10.
//

import UIKit
import RxSwift

final class ConsumptionAnalysisViewController: UIViewController {
    
    // MARK: - UI properties
    
    struct UIConstants {
        static let inset = 30
        static let cellHeight = 22
        static let cellSpacing = 20
        static let graphHeight = 264
    }
    
    private let timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemGray4
        label.font = UIFont.systemFont(ofSize: 15)
        label.text = "2023.05.15 월 23:15 기준"
        return label
    }()
    
    private var collectionView: UICollectionView!
    
    private let areaAndHouseholdLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemGray4
        label.font = UIFont.systemFont(ofSize: 15)
        label.textAlignment = .right
        label.text = "인하대학교 기준"
        return label
    }()
    
    private let notExistDataLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = .white
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.text = "아직 데이터가 존재하지 않아요"
        label.isHidden = true
        return label
    }()
    
    private var consumptionGraph: ConsumptionGraph!
    
    // MARK: - Properties
    
    private let viewModel: ConsumptionAnalysisViewModel
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(viewModel: ConsumptionAnalysisViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureCollectionView()
        configureConsumptionGraph()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    private func configureCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(view.frame.width - CGFloat(UIConstants.inset*2)),
            height: CGFloat(UIConstants.cellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.cellSpacing)
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        collectionView.register(AnalysisCollectionViewCell.self, forCellWithReuseIdentifier: AnalysisCollectionViewCell.identifier)
        collectionView.isScrollEnabled = false
    }
    
    private func configureConsumptionGraph() {
        let frame = CGRect(x: 0, y: 0, width: Int(self.view.frame.width) - UIConstants.inset*2, height: UIConstants.graphHeight)
        consumptionGraph = ConsumptionGraph(frame: frame)
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        
        view.addSubview(timeLabel)
        view.addSubview(collectionView)
        view.addSubview(areaAndHouseholdLabel)
        view.addSubview(consumptionGraph)
        view.addSubview(notExistDataLabel)
        
        configureUI()
    }
    
    private func configureUI() {
        timeLabel.snp.makeConstraints {
            $0.top.leading.trailing.equalToSuperview().inset(UIConstants.inset)
            $0.height.equalTo(UIConstants.cellHeight)
        }
        collectionView.snp.makeConstraints {
            $0.top.equalTo(timeLabel.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.equalTo(timeLabel)
            let cellCount = AnalysisLabelType.allCases.count
            let height = UIConstants.cellHeight * cellCount + UIConstants.cellSpacing * (cellCount - 1)
            $0.height.equalTo(height)
        }
        areaAndHouseholdLabel.snp.makeConstraints {
            $0.top.equalTo(collectionView.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.equalTo(timeLabel)
            $0.height.equalTo(UIConstants.cellHeight)
        }
        consumptionGraph.snp.makeConstraints {
            $0.top.equalTo(areaAndHouseholdLabel.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.equalTo(timeLabel)
            $0.height.equalTo(264)
        }
        
        notExistDataLabel.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
    
    private func bind() {
        let input = ConsumptionAnalysisViewModel.Input(
            viewWillAppear: rx.methodInvoked(#selector(viewWillAppear(_:))).map{ _ in }.asObservable()
        )
        let output = viewModel.transform(input)
        
        output.dataExist
            .subscribe(onNext: { [weak self] isExist in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.notExistDataLabel.isHidden = isExist
                }
            })
            .disposed(by: disposeBag)
        
        output.updatedDate
            .subscribe(onNext: { [weak self] updatedDate in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.timeLabel.text = updatedDate
                }
            })
            .disposed(by: disposeBag)
        
        output.consumptionAndRanking
            .bind(to: collectionView.rx.items(cellIdentifier: AnalysisCollectionViewCell.identifier, cellType: AnalysisCollectionViewCell.self)) { (index, item, cell) in
                let title = AnalysisLabelType(rawValue: index)?.title ?? ""
                cell.bind(title: title, value: item)
            }
            .disposed(by: disposeBag)
        
        output.areaAndHouseHold
            .subscribe(onNext: { [weak self] areaAndHousehold in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.areaAndHouseholdLabel.text = areaAndHousehold
                }
            })
            .disposed(by: disposeBag)
        
        output.graphData
            .subscribe(onNext: { (type, data) in
                DispatchQueue.main.async {
                    self.consumptionGraph.drawLine(consumptionType: type, items: data)
                }
            })
            .disposed(by: disposeBag)
    }
}
