//
//  EnergyViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/21.
//

import UIKit
import RxSwift
import SnapKit

final class EnergyViewController: UIViewController {

    // MARK: - UI properties
    
    private var segmentedControl: CustomSegmentedControl!
    
    private var subViewControllers: [UIViewController] = []
    private var pageViewController: UIPageViewController!
    
    // MARK: - Properties
    
    let type: EnergyType
    
    var currentPageIndex: Int = 0 { // segmentedControl -> pageViewControll Update
        didSet {
            let navigationDirection: UIPageViewController.NavigationDirection = oldValue <= currentPageIndex ? .forward : .reverse
            pageViewController.setViewControllers(
                [subViewControllers[currentPageIndex]],
                direction: navigationDirection,
                animated: true
            )
        }
    }
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(type: EnergyType) {
        self.type = type
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initializeProperties()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func initializeProperties() {
        initializeSegmentedControl()
        initializePageViewController()
    }
    
    private func initializeSegmentedControl() {
        segmentedControl = {
            let segmentedControl = CustomSegmentedControl(
                items: ConsumptionSegmentType.allCases.map{ $0.title }
            )
            segmentedControl.translatesAutoresizingMaskIntoConstraints = false
            return segmentedControl
        }()
    }
    
    private func initializePageViewController() {
        let consumptionRepository = ConsumptionRepository()
        let analysisUseCase = ConsumptionAnalysisUseCase(consumptionRepository: consumptionRepository)
        let analysisViewModel = ConsumptionAnalysisViewModel(energyType: type, usecase: analysisUseCase)
        let analysisViewController = ConsumptionAnalysisViewController(viewModel: analysisViewModel)
        
        analysisViewModel.showIndicator
            .subscribe(onNext: { showIndicator in
                DispatchQueue.main.async {
                    if showIndicator { analysisViewController.showIndicator() }
                    else { analysisViewController.hideIndicator() }
                }
            })
            .disposed(by: disposeBag)
        
        let rankingUseCase = ConsumptionRankingUseCase(consumptionRepository: consumptionRepository)
        let rankingViewModel = ConsumptionRankingViewModel(energyType: type, usecase: rankingUseCase)
        let rankingViewController = ConsumptionRankingViewController(viewModel: rankingViewModel)
        
        rankingViewModel.showIndicator
            .subscribe(onNext: { showIndicator in
                DispatchQueue.main.async {
                    if showIndicator { rankingViewController.showIndicator() }
                    else { rankingViewController.hideIndicator() }
                }
            })
            .disposed(by: disposeBag)
        
        subViewControllers = [analysisViewController, rankingViewController]
        
        pageViewController = {
            let pageViewController = UIPageViewController(
                transitionStyle: .scroll,
                navigationOrientation: .horizontal
            )
            pageViewController.setViewControllers(
                [self.subViewControllers[0]],
                direction: .forward,
                animated: true
            )
            pageViewController.dataSource = self
            pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
            return pageViewController
        }()
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        
        view.addSubview(segmentedControl)
        view.addSubview(pageViewController.view)
        
        configureUI()
        
        segmentedControl.selectedSegmentIndex = 0
    }
    
    private func configureUI() {
        segmentedControl.snp.makeConstraints {
            $0.top.leading.trailing.equalTo(view.safeAreaLayoutGuide)
            $0.height.equalTo(45)
        }
        pageViewController.view.snp.makeConstraints {
            $0.top.equalTo(segmentedControl.snp.bottom)
            $0.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
    }
    
    private func bind() {
        segmentedControl.rx.selectedSegmentIndex
            .subscribe(onNext: { [weak self] index in
                guard let self else { return }
                self.currentPageIndex = index
            })
            .disposed(by: disposeBag)
        
        pageViewController.rx.gestureDrivenTransitionCompleted
            .subscribe(onNext: { [weak self] in
                guard let self,
                      let viewController = self.pageViewController.viewControllers?[0],
                      let index = self.subViewControllers.firstIndex(of: viewController) else {
                    return
                }
                self.currentPageIndex = index
                self.segmentedControl.selectedSegmentIndex = index
            })
            .disposed(by: disposeBag)
    }

}

extension EnergyViewController: UIPageViewControllerDataSource {
    
    func pageViewController(
        _ pageViewController: UIPageViewController,
        viewControllerAfter viewController: UIViewController
    ) -> UIViewController? {
        guard let index = subViewControllers.firstIndex(of: viewController),
              index+1 < subViewControllers.count else {
            return nil
        }
        return subViewControllers[index+1]
    }
    
    func pageViewController(
        _ pageViewController: UIPageViewController,
        viewControllerBefore viewController: UIViewController
    ) -> UIViewController? {
        guard let index = subViewControllers.firstIndex(of: viewController),
              index-1 >= 0 else {
            return nil
        }
        return subViewControllers[index-1]
    }
}
