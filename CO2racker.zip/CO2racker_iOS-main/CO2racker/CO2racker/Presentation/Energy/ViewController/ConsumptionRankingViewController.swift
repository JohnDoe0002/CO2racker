//
//  RankingViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/10.
//

import UIKit
import SnapKit
import RxSwift

final class ConsumptionRankingViewController: UIViewController {
    
    // MARK: - UI properties
    
    private let scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()
    private let contentView = UIView()
    
    private var topRankCollectionView: UICollectionView!
    private var lowerRankCollectionView: UICollectionView!
    
    struct UIConstants {
        static let inset = 15
        static let topCollectionViewInset = 30
        static let topRankCellHeight = 161
        static let topRankCellSpacing = 15
        static let lowerRankCellHeight = 58
        static let lowerRankCellSpacing = 10
    }
    
    // MARK: - Properties
    
    private let viewModel: ConsumptionRankingViewModel
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(viewModel: ConsumptionRankingViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        configureCollectionView()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func configureCollectionView() {
        configureTopRankCollectionView()
        configureLowerRankCollectionView()
    }
    
    private func configureTopRankCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        let cellWidth = (Int(view.frame.width) - UIConstants.topCollectionViewInset * 2 - UIConstants.topRankCellSpacing * 2) / 3
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(cellWidth),
            height: CGFloat(UIConstants.topRankCellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.topRankCellSpacing)
        topRankCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        topRankCollectionView.register(TopRankCollectionViewCell.self, forCellWithReuseIdentifier: TopRankCollectionViewCell.identifier)
        topRankCollectionView.isScrollEnabled = false
    }

    private func configureLowerRankCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: (view.frame.width - CGFloat(UIConstants.inset) * 2),
            height: CGFloat(UIConstants.lowerRankCellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.lowerRankCellSpacing)
        lowerRankCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        lowerRankCollectionView.register(LowerRankCollectionViewCell.self, forCellWithReuseIdentifier: LowerRankCollectionViewCell.identifier)
        lowerRankCollectionView.isScrollEnabled = false
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        contentView.addSubview(topRankCollectionView)
        contentView.addSubview(lowerRankCollectionView)
        
        configureUI()
    }
    
    private func configureUI() {
        scrollView.snp.makeConstraints {
            $0.top.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
        contentView.snp.makeConstraints {
            $0.top.leading.trailing.bottom.equalToSuperview()
            $0.width.equalToSuperview()
        }
        topRankCollectionView.snp.makeConstraints {
            $0.top.leading.trailing.equalToSuperview().inset(UIConstants.topCollectionViewInset)
            $0.height.equalTo(UIConstants.topRankCellHeight)
        }
        lowerRankCollectionView.snp.makeConstraints {
            $0.top.equalTo(topRankCollectionView.snp.bottom).offset(22)
            $0.leading.trailing.equalToSuperview().inset(UIConstants.inset)
            $0.height.equalTo(0)
            $0.bottom.equalToSuperview()
        }
    }
    
    private func bind() {
        let input = ConsumptionRankingViewModel.Input(
            viewWillAppear: rx.methodInvoked(#selector(viewWillAppear(_:))).map{ _ in }.asObservable()
        )
        let output = viewModel.transform(input)
        
        output.top3Ranking
            .bind(to: topRankCollectionView.rx.items(
                cellIdentifier: TopRankCollectionViewCell.identifier,
                cellType: TopRankCollectionViewCell.self
            )) { (index, item, cell) in
                cell.bind(rank: index, nickName: item.nickname, consumption: String(item.consumption) + item.type.unit)
            }
            .disposed(by: disposeBag)
        
        output.lowerRanking
            .do(onNext: { [weak self] data in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.lowerRankCollectionView.snp.updateConstraints {
                        let height = (UIConstants.lowerRankCellHeight + UIConstants.lowerRankCellSpacing) * data.count
                        $0.height.equalTo(height)
                    }
                }
            })
            .bind(to: lowerRankCollectionView.rx.items(
                cellIdentifier: LowerRankCollectionViewCell.identifier,
                cellType: LowerRankCollectionViewCell.self
            )) { (index, item, cell) in
                cell.bind(rank: index + 3, nickName: item.nickname, consumption: String(item.consumption) + item.type.unit)
            }
            .disposed(by: disposeBag)
    }
}
