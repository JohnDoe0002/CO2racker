//
//  LowerRankCollectionViewCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import UIKit
import SnapKit

final class LowerRankCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "LowerRankCollectionViewCell"
    
    // MARK: - UI Properties
    
    private let rankLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 18)
        label.text = "4위"
        return label
    }()
    
    private let nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 18)
        label.text = "user1"
        return label
    }()
    
    private let consumptionLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 18)
        label.textAlignment = .right
        label.text = "1000kWh"
        return label
    }()
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        backgroundColor = .systemGray3
        self.layer.cornerRadius = 10
        
        addSubview(rankLabel)
        addSubview(nicknameLabel)
        addSubview(consumptionLabel)
        
        configureUI()
    }
    
    private func configureUI() {
        rankLabel.snp.makeConstraints {
            $0.leading.equalToSuperview().inset(20)
            $0.centerY.equalToSuperview()
            $0.height.equalTo(22)
            $0.width.equalTo(40)
        }
        nicknameLabel.snp.makeConstraints {
            $0.centerY.height.equalTo(rankLabel)
            $0.leading.equalTo(rankLabel.snp.trailing).offset(20)
            $0.width.equalTo(130)
        }
        consumptionLabel.snp.makeConstraints {
            $0.centerY.height.equalTo(rankLabel)
            $0.trailing.equalToSuperview().inset(20)
            $0.width.equalTo(120)
        }
    }

    func bind(rank: Int, nickName: String, consumption: String) {
        rankLabel.text = String(rank+1) + "위"
        nicknameLabel.text = nickName
        consumptionLabel.text = consumption
    }
}
