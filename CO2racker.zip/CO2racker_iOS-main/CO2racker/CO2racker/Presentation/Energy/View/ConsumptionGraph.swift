//
//  ConsumptionGraph.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import UIKit
import SnapKit
import RxSwift

final class ConsumptionGraph: UIView {
    
    struct UIConstants {
        static let labelHeight = 22
        static let offset = 10
        static let viewHeight = 264
        static let cellWidth = 18
    }
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 17)
        label.text = "시간별 소비량 그래프"
        return label
    }()
    private let contentView = UIView()
    private var hourCollectionView: UICollectionView!
    
    private let disposeBag = DisposeBag()
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        configureCollectionView()
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    private func configureCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(UIConstants.cellWidth),
            height: CGFloat(UIConstants.labelHeight)
        )
        collectionViewFlowLayout.minimumInteritemSpacing = (self.frame.width - CGFloat(UIConstants.cellWidth) * 9) / 8
        hourCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        hourCollectionView.register(GraphHourCollectionViewCell.self, forCellWithReuseIdentifier: GraphHourCollectionViewCell.identifier)
        hourCollectionView.isScrollEnabled = false
        
        Observable<[Int]>.just(Array(0...8))
            .bind(to: hourCollectionView.rx.items(
                cellIdentifier: GraphHourCollectionViewCell.identifier,
                cellType: GraphHourCollectionViewCell.self
            )) { (_, item, cell) in
                cell.bind(hour: item * 3)
            }
            .disposed(by: disposeBag)
    }
    
    private func setupViews() {
        addSubview(titleLabel)
        addSubview(contentView)
        addSubview(hourCollectionView)
        configureUI()
        
        contentView.layer.borderColor = UIColor.systemGray2.cgColor
        contentView.layer.borderWidth = 1
        contentView.clipsToBounds = true
    }
    
    private func configureUI() {
        titleLabel.snp.makeConstraints {
            $0.top.leading.trailing.equalToSuperview()
            $0.height.equalTo(UIConstants.labelHeight)
        }
        contentView.snp.makeConstraints {
            $0.top.equalTo(titleLabel.snp.bottom).offset(UIConstants.offset)
            $0.leading.trailing.equalTo(titleLabel)
            let height = UIConstants.viewHeight - (UIConstants.labelHeight + UIConstants.offset) * 2
            $0.height.equalTo(height)
        }
        hourCollectionView.snp.makeConstraints {
            $0.top.equalTo(contentView.snp.bottom).offset(UIConstants.offset)
            $0.leading.trailing.equalTo(titleLabel)
            $0.height.equalTo(UIConstants.labelHeight)
        }
    }
    
    func drawLine(consumptionType: EnergyType, items: [ConsumptionGraphItem]) {
        if items.isEmpty { return }
        
        let layer = CAShapeLayer()
        let path = UIBezierPath()
        
        let height = contentView.frame.height
        let dx = (contentView.frame.width) / 24
        
        guard let minValue = items.map({ $0.amount }).min() else { return }
        let yRatio = height / consumptionType.dailyMaxAmount
        
        var x: CGFloat = 0
        let startPoint = CGPoint(x: x, y: height)
        path.move(to: startPoint)
        
        if items.count > 1 {
            for i in 1..<items.count {
                x += dx
                let ny = height - CGFloat(items[i].amount - minValue) * yRatio
                let nextPoint = CGPoint(x: x, y: ny)
                path.addLine(to: nextPoint)
            }
        }
            
        layer.fillColor = nil
        layer.strokeColor = UIColor.mainColor.cgColor
        layer.lineWidth = 1
        layer.path = path.cgPath
        contentView.layer.addSublayer(layer)
        
        draw(.zero)
    }

}
