//
//  GraphHourCollectionViewCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/18.
//

import UIKit
import SnapKit

final class GraphHourCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "GraphHourCollectionViewCell"
    
    // MARK: - UI Properties
    
    private let hourLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        addSubview(hourLabel)
        hourLabel.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }

    func bind(hour: Int) {
        hourLabel.text = hour < 10 ? "0\(hour)" : String(hour)
    }
}
