//
//  TopRankCollectionViewCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import UIKit
import SnapKit

final class TopRankCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "TopRankCollectionViewCell"
    
    // MARK: - UI Properties
    
    private let medalImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private let nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 16)
        label.textAlignment = .center
        label.text = "user1"
        return label
    }()
    
    private let consumptionLabel: UILabel = {
        let label = UILabel()
        label.textColor = .mainColor
        label.font = UIFont.systemFont(ofSize: 16)
        label.textAlignment = .center
        label.text = "1000kWh"
        return label
    }()
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        addSubview(medalImageView)
        addSubview(nicknameLabel)
        addSubview(consumptionLabel)
        
        configureUI()
    }
    
    private func configureUI() {
        medalImageView.snp.makeConstraints {
            $0.top.leading.trailing.equalToSuperview()
            $0.height.equalTo(110)
        }
        nicknameLabel.snp.makeConstraints {
            $0.top.equalTo(medalImageView.snp.bottom).offset(5)
            $0.leading.trailing.equalTo(medalImageView)
            $0.height.equalTo(22)
        }
        consumptionLabel.snp.makeConstraints {
            $0.top.equalTo(nicknameLabel.snp.bottom).offset(2)
            $0.leading.trailing.equalTo(medalImageView)
            $0.height.equalTo(nicknameLabel)
        }
    }

    
    func bind(rank: Int, nickName: String, consumption: String) {
        medalImageView.image = RankMedal(rawValue: rank)?.image
        nicknameLabel.text = nickName
        consumptionLabel.text = consumption
    }
}
