//
//  AnalysisCollectionViewCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/15.
//

import UIKit
import SnapKit

final class AnalysisCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "AnalysisCollectionViewCell"
    
    // MARK: - UI properties
    
    private let titleAndValueLabel = TitleAndValueLabel()
    
    // MARK: - Lifecycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        addSubview(titleAndValueLabel)
        
        titleAndValueLabel.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
    
    func bind(title: String, value: String) {
        titleAndValueLabel.bind(title: title, value: value)
    }
}
