//
//  TabBarViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/21.
//

import UIKit

final class TabBarViewController: UITabBarController {
    
    // MARK: - Properties
    
    // MARK: - Lifecycles
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureUI()
    }
    
    // MARK: - Helpers
    
    private func configureUI() {
        tabBar.barTintColor = .mainColor        // 초기 색상
        tabBar.backgroundColor = .mainColor     // 스크롤 시 색상
        tabBar.isTranslucent = false
        tabBar.tintColor = .systemGray2               // TabBar Item Color
        tabBar.unselectedItemTintColor = .white
    }
}
