//
//  MainCoordinator.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import UIKit
import RxSwift

protocol TabBarCoordinatorProtocol: Coordinator {
    func showTabBarViewController()
    func startAuthFlow()
}

final class TabBarCoordinator: TabBarCoordinatorProtocol {
    
    weak var delegate: CoordinatorFinishDelegate?
    var navigationController: UINavigationController
    var childCoordinators: [Coordinator]
    
    private let disposeBag = DisposeBag()
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
        self.childCoordinators = []
    }
    
    func start() {
        navigationController.navigationBar.isHidden = true
        showTabBarViewController()
    }
    
    func showTabBarViewController() {
        let viewController = TabBarViewController()
        setupTabBarViewController(viewController)
        navigationController.pushViewController(viewController, animated: true)
    }
    
    private func setupTabBarViewController(_ tabBarViewController: UITabBarController) {
        let viewControllers = [
            createHomeViewController(),
            createEnergyViewController(type: .power),
            createEnergyViewController(type: .water),
            createEnergyViewController(type: .gas),
            createMyPageViewController()
        ]
        
        TabBarItemType.allCases.forEach {
            viewControllers[$0.rawValue].tabBarItem.image = UIImage(systemName: $0.itemImageSystemName)
            viewControllers[$0.rawValue].navigationItem.title = $0.title
        }
        
        let navigationControllers = viewControllers.map { UINavigationController(rootViewController: $0) }
        tabBarViewController.setViewControllers(navigationControllers, animated: true)
    }
    
    // MARK: - create ViewControllers
    
    private func createHomeViewController() -> HomeViewController {
        let consumptionRepository = ConsumptionRepository()
        let userRepository = UserRepository()
        let usecase = HomeUseCase(
            consumptionRepository: consumptionRepository,
            userRepository: userRepository
        )
        let viewModel = HomeViewModel(usecase: usecase)
        let viewController = HomeViewController(viewModel: viewModel)
        
        viewModel.showIndicator
            .subscribe(onNext: { showIndicator in
                DispatchQueue.main.async {
                    if showIndicator {
                        viewController.showIndicator()
                    } else {
                        viewController.hideIndicator()
                    }
                }
            })
            .disposed(by: disposeBag)
        
        return viewController
    }
    
    private func createEnergyViewController(type: EnergyType) -> EnergyViewController {
        let viewController = EnergyViewController(type: type)
        return viewController
    }
    
    private func createMyPageViewController() -> MyPageViewController {
        let userRepository = UserRepository()
        let authRepository = AuthRepository()
        let usecase = MyPageUseCase(userRepository: userRepository, authRepository: authRepository)
        let viewModel = MyPageViewModel(usecase: usecase)
        let viewController = MyPageViewController(viewModel: viewModel)
        
        viewModel.showIndicator
            .subscribe(onNext: { showIndicator in
                DispatchQueue.main.async {
                    if showIndicator { self.navigationController.showIndicator() }
                    else { self.navigationController.hideIndicator() }
                }
            })
            .disposed(by: disposeBag)
        
        viewModel.showPointChangeView
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showPointChangeViewController(on: viewController)
            })
            .disposed(by: disposeBag)
        
        viewModel.showCouponBoxView
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showCouponBoxViewController(on: viewController)
            })
            .disposed(by: disposeBag)
        
        viewModel.showUserInfoEditView
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showUserInfoEditViewController(on: viewController)
            })
            .disposed(by: disposeBag)
        
        viewModel.showLoginViewController
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                startAuthFlow()
            })
            .disposed(by: disposeBag)
        
        return viewController
    }
    
    private func showPointChangeViewController(on parentViewController: UIViewController) {
        let gifticonRepository = GifticonRepository()
        let usecase = PointChangeUseCase(gifticonRepository: gifticonRepository)
        let viewModel = PointChangeViewModel(usecase: usecase)
        let viewController = PointChangeViewController(viewModel: viewModel)
        
        viewModel.showGifticonViewController
            .subscribe(onNext: { 
                DispatchQueue.main.async {
                    self.showGifticonViewController(on: parentViewController, showDescription: true)
                }
            })
            .disposed(by: disposeBag)
        
        parentViewController.navigationController?.pushViewController(viewController, animated: true)
    }
    
    private func showGifticonViewController(on parentViewController: UIViewController, showDescription: Bool) {
        let viewController = GifticonViewController(showDescription: showDescription)
        parentViewController.navigationController?.pushViewController(viewController, animated: true)
    }
    
    private func showCouponBoxViewController(on parentViewController: UIViewController) {
        let userRepository = UserRepository()
        let usecase = CouponBoxUseCase(userRepository: userRepository)
        let viewModel = CouponBoxViewModel(usecase: usecase)
        let viewController = CouponBoxViewController(viewModel: viewModel)
        
        viewModel.showIndicator
            .subscribe(onNext: { showIndicator in
                DispatchQueue.main.async {
                    if showIndicator { self.navigationController.showIndicator() }
                    else { self.navigationController.hideIndicator() }
                }
            })
            .disposed(by: disposeBag)
        
        viewModel.showGifticonViewController
            .subscribe(onNext: {
                DispatchQueue.main.async {
                    self.showGifticonViewController(on: parentViewController, showDescription: false)
                }
            })
            .disposed(by: disposeBag)
        
        parentViewController.navigationController?.pushViewController(viewController, animated: true)
    }
    
    private func showUserInfoEditViewController(on parentViewController: UIViewController) {
        let userRepository = UserRepository()
        let usecase = UserInfoEditUseCase(userRepository: userRepository)
        let viewModel = UserInfoEditViewModel(usecase: usecase)
        let viewController = UserInfoEditViewController(viewModel: viewModel)
        
        viewModel.showIndicator
            .subscribe(onNext: { showIndicator in
                DispatchQueue.main.async {
                    if showIndicator { self.navigationController.showIndicator() }
                    else { self.navigationController.hideIndicator() }
                }
            })
            .disposed(by: disposeBag)
        
        viewModel.returnToMyPageViewController
            .subscribe(onNext: {
                DispatchQueue.main.async {
                    parentViewController.navigationController?.popToViewController(parentViewController, animated: true)
                }
            })
            .disposed(by: disposeBag)
        
        viewModel.showPostCodeWebView
            .subscribe(onNext: { [weak self] addressSubject in
                guard let self else { return }
                showPostCodeWebViewController(
                    on: parentViewController,
                    addressSubject: addressSubject
                )
            })
            .disposed(by: disposeBag)
        
        parentViewController.navigationController?.pushViewController(viewController, animated: true)
    }
    
    func showPostCodeWebViewController(
        on parentViewController: UIViewController,
        addressSubject: PublishSubject<String>
    ) {
        let viewController = PostCodeWebViewController(addressSubject)
        parentViewController.navigationController?.present(viewController, animated: true)
    }
    
    func startAuthFlow() {
        delegate?.didFinished(self)
    }
}
