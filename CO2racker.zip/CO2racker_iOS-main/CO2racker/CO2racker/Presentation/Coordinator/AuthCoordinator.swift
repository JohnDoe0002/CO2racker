//
//  AuthCoordinator.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import UIKit
import RxSwift

protocol AuthCoordinatorProtocol: Coordinator {
    func showLoginViewController()
    func showSignUpViewController()
    func showPostCodeWebViewController(_ addressSubject: PublishSubject<String>)
    func startMainFlow()
}

final class AuthCoordinator: AuthCoordinatorProtocol {

    var navigationController: UINavigationController
    var childCoordinators: [Coordinator]
    weak var delegate: CoordinatorFinishDelegate?
    
    private let disposeBag = DisposeBag()
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
        self.childCoordinators = []
    }
    
    func start() {
        showLoginViewController()
    }
    
    func showLoginViewController() {
        let usecase = LoginUseCase(authRepository: AuthRepository())
        let viewModel = LoginViewModel(usecase: usecase)
        let viewController = LoginViewController(viewModel: viewModel)
        
        viewModel.showSignUpViewController
            .withUnretained(self)
            .subscribe(onNext: { (owner, _) in
                owner.showSignUpViewController()
            })
            .disposed(by: disposeBag)
        
        viewModel.startMainFlow
            .withUnretained(self)
            .subscribe(onNext: { (owner, _) in
                owner.startMainFlow()
            })
            .disposed(by: disposeBag)
        
        viewModel.showAlert
            .withUnretained(self)
            .subscribe(onNext: { (owner, alertType) in
                owner.navigationController.showAlert(
                    title: alertType.title,
                    message: alertType.message,
                    type: .oneButton
                )
            })
            .disposed(by: disposeBag)
        
        viewModel.showIndicator
            .withUnretained(self)
            .subscribe(onNext: { (owner, showIndicator) in
                if showIndicator {
                    owner.navigationController.viewControllers.last?.showIndicator()
                } else {
                    owner.navigationController.viewControllers.last?.hideIndicator()
                }
            })
            .disposed(by: disposeBag)
        
        navigationController.pushViewController(viewController, animated: true)
    }
    
    func showSignUpViewController() {
        let usecase = SignUpUseCase(authRepository: AuthRepository())
        let viewModel = SignUpViewModel(usecase: usecase)
        let viewController = SignUpViewController(viewModel: viewModel)
        
        viewModel.showLoginViewController
            .withUnretained(self)
            .subscribe(onNext: { (owner, _) in
                let alertType = AlertMessageType.signUpSuccess
                owner.navigationController.showAlert(
                    title: alertType.title,
                    message: alertType.message,
                    type: .oneButton,
                    rightActionHandler: {
                        owner.returnToLoginViewController()
                    })
            })
            .disposed(by: disposeBag)
        
        viewModel.showPostCodeWebView
            .withUnretained(self)
            .subscribe(onNext: { (owner, addressSubject) in
                owner.showPostCodeWebViewController(addressSubject)
            })
            .disposed(by: disposeBag)
        
        viewModel.showAlert
            .withUnretained(self)
            .subscribe(onNext: { (owner, alertType) in
                owner.navigationController.showAlert(
                    title: alertType.title,
                    message: alertType.message,
                    type: .oneButton
                )
            })
            .disposed(by: disposeBag)
        
        viewModel.showIndicator
            .withUnretained(self)
            .subscribe(onNext: { (owner, showIndicator) in
                if showIndicator {
                    owner.navigationController.viewControllers.last?.showIndicator()
                } else {
                    owner.navigationController.viewControllers.last?.hideIndicator()
                }
            })
            .disposed(by: disposeBag)
        
        navigationController.pushViewController(viewController, animated: true)
    }
    
    func showPostCodeWebViewController(_ addressSubject: PublishSubject<String>) {
        let viewController = PostCodeWebViewController(addressSubject)
        navigationController.present(viewController, animated: true)
    }
    
    func startMainFlow() {
        delegate?.didFinished(self)
    }
    
    private func returnToLoginViewController() {
        navigationController.popToRootViewController(animated: true)  // root is LoginViewController
    }
}
