//
//  Coordinator.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import UIKit

protocol Coordinator: AnyObject {
    var childCoordinators: [Coordinator] { get set }
    
    func start()
}

extension Coordinator {
    func removeChild(_ coordinator: Coordinator) {
        childCoordinators = childCoordinators.filter{ $0 !== coordinator }
    }
}

protocol CoordinatorFinishDelegate: AnyObject {
    func didFinished(_ childCoordinator: Coordinator)
}
