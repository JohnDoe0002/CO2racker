//
//  AppCoordinator.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/21.
//

import UIKit

final class AppCoordinator: Coordinator {
    
    var childCoordinators: [Coordinator]
    let window: UIWindow?
    
    init(_ window: UIWindow?) {
        self.childCoordinators = []
        self.window = window
        window?.makeKeyAndVisible()
    }
    
    func start() {
        // 로그인 여부 따라 첫 화면 결정
//        if isLoggedIn {
            connectAuthFlow()
//        } else {
//            connectTabBarFlow()
//        }
    }
    
    func connectAuthFlow() {
        let navigationController = UINavigationController()
        let authCoordinator = AuthCoordinator(navigationController: navigationController)
        
        authCoordinator.delegate = self
        authCoordinator.start()
        
        childCoordinators.append(authCoordinator)
        window?.rootViewController = navigationController
    }
    
    func connectTabBarFlow() {
        let navigationController = UINavigationController()
        let tabBarCoordinator = TabBarCoordinator(navigationController: navigationController)
        
        tabBarCoordinator.delegate = self
        tabBarCoordinator.start()
        
        childCoordinators.append(tabBarCoordinator)
        window?.rootViewController = navigationController
    }
}

extension AppCoordinator: CoordinatorFinishDelegate {
    func didFinished(_ childCoordinator: Coordinator) {
        removeChild(childCoordinator)
        
        switch childCoordinator {
        case is AuthCoordinator:
            connectTabBarFlow()
        case is TabBarCoordinator:
            connectAuthFlow()
        default:
            return
        }
    }
}
