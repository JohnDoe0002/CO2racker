//
//  SettingViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/21.
//

import UIKit
import SnapKit
import RxSwift

enum MyPageSection: Int, CaseIterable {
    case point
    case setting
    
    var title: String {
        switch self {
        case .point:
            return "포인트"
        case .setting:
            return "설정"
        }
    }
    
    var items: [String] {
        switch self {
        case .point:
            return ["포인트 전환", "내 쿠폰함", "알림"]
        case .setting:
            return ["회원정보 수정", "로그아웃", "탈퇴"]
        }
    }
}

final class MyPageViewController: UIViewController {
    
    // MARK: - UI properties
    
    private let userInfoView = UserInfoView()
    private var collectionView: UICollectionView!
    
    // MARK: - Properties
    
    private let viewModel: MyPageViewModel
    
    private let pointChangeDidTapped = PublishSubject<Void>()
    private let couponBoxDidTapped = PublishSubject<Void>()
    private let notificationDidTapped = PublishSubject<Void>()
    private let userInfoEditDidTapped = PublishSubject<Void>()
    private let logoutDidTapped = PublishSubject<Void>()
    private let withdrawlDidTapped = PublishSubject<Void>()
    private let showLoginView = PublishSubject<Void>()
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(viewModel: MyPageViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureCollectionView()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func configureCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: view.frame.width,
            height: 50
        )
        collectionViewFlowLayout.headerReferenceSize = CGSize(
            width: view.frame.width,
            height: 30
        )
        collectionViewFlowLayout.minimumLineSpacing = 0
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        
        collectionView.dataSource = self
        
        collectionView.register(
            MyPageCollectionViewCell.self,
            forCellWithReuseIdentifier: MyPageCollectionViewCell.identifier
        )
        collectionView.register(
            MyPageCollectionViewHeader.self,
            forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
            withReuseIdentifier: MyPageCollectionViewHeader.identifier
        )
    }
    
    private func setupViews() {
        view.backgroundColor = .white
        setupBackButton()
        
        view.addSubview(userInfoView)
        view.addSubview(collectionView)
        
        configureUI()
    }
    
    private func configureUI() {
        userInfoView.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide).offset(10)
            $0.leading.trailing.equalTo(view.safeAreaLayoutGuide)
            $0.height.equalTo(95)
        }
        collectionView.snp.makeConstraints {
            $0.top.equalTo(userInfoView.snp.bottom).offset(10)
            $0.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
    }
    
    private func bind() {
        let input = MyPageViewModel.Input(
            viewWillAppear: rx.methodInvoked(#selector(viewWillAppear(_:))).map{ _ in },
            pointChangeDidTapped: pointChangeDidTapped,
            couponBoxDidTapped: couponBoxDidTapped,
            notificationDidTapped: notificationDidTapped,
            userInfoEditDidTapped: userInfoEditDidTapped,
            logoutDidTapped: logoutDidTapped,
            withdrawlDidTapped: withdrawlDidTapped,
            showLoginView: showLoginView
        )
        let output = viewModel.transform(input)
        
        bindCollectionViewSelection()
        
        output.userInfo
            .subscribe(onNext: { [weak self] user in
                guard let self else { return }
                DispatchQueue.main.async {
                    self.userInfoView.bind(user)
                }
            })
            .disposed(by: disposeBag)
        
        output.showAlert
            .subscribe(onNext: { messageType in
                DispatchQueue.main.async {
                    switch messageType {
                    case .signOutSuccess, .withdrawalSuccess:
                        self.showAlert(title: messageType.title, type: .oneButton, rightActionHandler: { [weak self] in
                            guard let self else { return }
                            showLoginView.onNext(())
                        })
                    case .signOutFailure, .withdrawalFailure:
                        self.showAlert(
                            title: messageType.title,
                            message: messageType.message,
                            type: .oneButton
                        )
                    default:
                        break
                    }
                }
            })
            .disposed(by: disposeBag)
    }
    
    private func bindCollectionViewSelection() {
        collectionView.rx.itemSelected.asObservable()
            .subscribe(onNext: { [weak self] indexpath in
                guard let self else { return }
                
                if MyPageSection.point.rawValue == indexpath.section {
                    switch indexpath.row {
                    case 0:
                        pointChangeDidTapped.onNext(())
                    case 1:
                        couponBoxDidTapped.onNext(())
                    case 2:
                        notificationDidTapped.onNext(())
                    default:
                        break
                    }
                } else if MyPageSection.setting.rawValue == indexpath.section {
                    switch indexpath.row {
                    case 0:
                        userInfoEditDidTapped.onNext(())
                    case 1:
                        showAlert(
                            title: AlertMessageType.reconfirmSignOut.title,
                            type: .twoButton,
                            rightActionHandler: { [weak self] in
                                guard let self else { return }
                                logoutDidTapped.onNext(())
                            }
                        )
                    case 2:
                        showAlert(
                            title: AlertMessageType.reconfirmWithdrawal.title,
                            type: .twoButton,
                            rightActionHandler: { [weak self] in
                                guard let self else { return }
                                withdrawlDidTapped.onNext(())
                            }
                        )
                    default:
                        break
                    }
                }
            })
            .disposed(by: disposeBag)
    }
}

// MARK: - UICollectionView DataSource

extension MyPageViewController: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        MyPageSection.allCases.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let section = MyPageSection(rawValue: section) else { return 0 }
        return section.items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MyPageCollectionViewCell.identifier, for: indexPath) as? MyPageCollectionViewCell,
              let section = MyPageSection(rawValue: indexPath.section) else {
            return MyPageCollectionViewCell()
        }
        let itemTitle = section.items[indexPath.row]
        cell.bind(title: itemTitle)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader {
            if let header = collectionView.dequeueReusableSupplementaryView(
                ofKind: kind,
                withReuseIdentifier: MyPageCollectionViewHeader.identifier,
                for: indexPath
            ) as? MyPageCollectionViewHeader,
               let section = MyPageSection(rawValue: indexPath.section) {
                header.bind(title: section.title)
                return header
            }
        }
        return UICollectionReusableView()
    }
}
