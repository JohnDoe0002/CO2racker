//
//  PointChangeViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/30.
//

import UIKit
import SnapKit
import RxSwift

final class PointChangeViewController: UIViewController {
    
    // MARK: - UI properties
    
    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = .coffeeImage
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private let descriptionLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 20)
        label.textAlignment = .center
        label.textColor = .black
        label.numberOfLines = 0
        label.text = "5000 포인트를 사용하여 스타벅스 아메리카노 (T) 기프티콘으로 전환할 수 있습니다."
        return label
    }()
    
    private let changeButton = MainColorButton(title: "포인트 전환")
    
    // MARK: - Properties
    
    private let viewModel: PointChangeViewModel
    
    private let changeOkDidTapped = PublishSubject<Void>()  // alert의 확인 버튼 클릭 이벤트
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(viewModel: PointChangeViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        title = "포인트 전환"
        view.backgroundColor = .white
        setupBackButton()
        
        view.addSubview(imageView)
        view.addSubview(descriptionLabel)
        view.addSubview(changeButton)
        
        configureUI()
    }
    
    private func configureUI() {
        imageView.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide).offset(60)
            $0.centerX.equalToSuperview()
            $0.width.height.equalTo(220)
        }
        descriptionLabel.snp.makeConstraints {
            $0.top.equalTo(imageView.snp.bottom).offset(60)
            $0.leading.trailing.equalTo(view.safeAreaLayoutGuide).inset(20)
        }
        changeButton.snp.makeConstraints {
            $0.top.equalTo(descriptionLabel.snp.bottom).offset(60)
            $0.centerX.equalToSuperview()
            $0.width.equalTo(150)
            $0.height.equalTo(50)
        }
    }
    
    private func bind() {
        let input = PointChangeViewModel.Input(changeButtonDidTapped: changeOkDidTapped)
        let output = viewModel.transform(input)
    
        bindChangeButton()
        
        output.pointChangeFailure
            .subscribe(onNext: { message in
                DispatchQueue.main.async {
                    self.showAlert(
                        title: AlertMessageType.pointChangeFailure.title,
                        message: message,
                        type: .oneButton
                    )
                }
            })
            .disposed(by: disposeBag)
    }
    
    private func bindChangeButton() {
        changeButton.rx.tap.asObservable()
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                let pointChangeAlertMessage = AlertMessageType.pointChange
                showAlert(
                    title: pointChangeAlertMessage.title,
                    message: AlertMessageType.pointChange.message,
                    type: .twoButton,
                    rightActionHandler: { [weak self] in
                        guard let self else { return }
                        changeOkDidTapped.onNext(())
                    }
                )
            })
            .disposed(by: disposeBag)
    }
}
