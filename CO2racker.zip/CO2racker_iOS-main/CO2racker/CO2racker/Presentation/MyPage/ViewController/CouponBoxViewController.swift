//
//  CouponBoxViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import UIKit
import SnapKit
import RxSwift

final class CouponBoxViewController: UIViewController {
    
    // MARK: - UI properties
    private let segmentedControl: CustomSegmentedControl = {
        let segmentedControl = CustomSegmentedControl(
            items: CouponBoxSegmentType.allCases.map{ $0.title }
        )
        segmentedControl.translatesAutoresizingMaskIntoConstraints = false
        return segmentedControl
    }()
    
    private var receivedCouponCollectionView: UICollectionView!
    
    private var usedCouponCollectionView: UICollectionView!
    
    struct UIConstants {
        static let inset = 10
        static let cellHeight = 90
        static let cellSpacing = 10
    }
    
    // MARK: - Properties
    
    private let viewModel: CouponBoxViewModel
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(viewModel: CouponBoxViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureCollectionView()
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func configureCollectionView() {
        configureReceivedCollectionView()
        configureUsedCollectionView()
    }
    
    private func configureReceivedCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(view.frame.width - CGFloat(UIConstants.inset*2)),
            height: CGFloat(UIConstants.cellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.cellSpacing)
        
        receivedCouponCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        receivedCouponCollectionView.register(CouponCollectionViewCell.self, forCellWithReuseIdentifier: CouponCollectionViewCell.identifier)
    }

    private func configureUsedCollectionView() {
        let collectionViewFlowLayout = UICollectionViewFlowLayout()
        collectionViewFlowLayout.itemSize = CGSize(
            width: CGFloat(view.frame.width - CGFloat(UIConstants.inset*2)),
            height: CGFloat(UIConstants.cellHeight)
        )
        collectionViewFlowLayout.minimumLineSpacing = CGFloat(UIConstants.cellSpacing)
        
        usedCouponCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionViewFlowLayout)
        usedCouponCollectionView.register(CouponCollectionViewCell.self, forCellWithReuseIdentifier: CouponCollectionViewCell.identifier)
    }

    private func setupViews() {
        title = "내 쿠폰함"
        view.backgroundColor = .white
        setupBackButton()
        
        segmentedControl.selectedSegmentIndex = 0
        
        view.addSubview(segmentedControl)
        view.addSubview(receivedCouponCollectionView)
        view.addSubview(usedCouponCollectionView)
        
        configureUI()
    }
    
    private func configureUI() {
        segmentedControl.snp.makeConstraints {
            $0.top.leading.trailing.equalTo(view.safeAreaLayoutGuide)
            $0.height.equalTo(45)
        }
        receivedCouponCollectionView.snp.makeConstraints {
            $0.top.equalTo(segmentedControl.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
        usedCouponCollectionView.snp.makeConstraints {
            $0.edges.equalTo(receivedCouponCollectionView)
        }
    }
    
    private func bind() {
        bindSegmentedControl()
        
        let input = CouponBoxViewModel.Input(
            viewWillAppear: rx.methodInvoked(#selector(viewWillAppear(_:))).map{ _ in }.asObservable(),
            receivedCouponDidTapped: receivedCouponCollectionView.rx.itemSelected.map{ $0.row }
        )
        let output = viewModel.transform(input)
        
        output.receivedCoupon
            .bind(to: receivedCouponCollectionView.rx.items(
                cellIdentifier: CouponCollectionViewCell.identifier,
                cellType: CouponCollectionViewCell.self
            )) { (_, _, _) in
            }
            .disposed(by: disposeBag)
        
        output.usedCoupon
            .bind(to: usedCouponCollectionView.rx.items(
                cellIdentifier: CouponCollectionViewCell.identifier,
                cellType: CouponCollectionViewCell.self
            )) { (_, _, _) in
            }
            .disposed(by: disposeBag)
    }
    
    private func bindSegmentedControl() {
        segmentedControl.rx.selectedSegmentIndex
            .subscribe(onNext: { [weak self] index in
                guard let self else { return }
                showReceivedCollectionView(index == CouponBoxSegmentType.received.index)
            })
            .disposed(by: disposeBag)
    }
    
    private func showReceivedCollectionView(_ show: Bool) {
        receivedCouponCollectionView.isHidden = !show
        usedCouponCollectionView.isHidden = show
    }
}
