//
//  UserInfoEditViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import UIKit
import SnapKit
import RxSwift

final class UserInfoEditViewController: UIViewController {
    
    // MARK: - UI properties
    
    private let nicknameTextfield = CommonTextfieldCell(
        title: AuthTextfieldType.nickname.title
    )

    private let passwordTextfield = CommonTextfieldCell(
        title: AuthTextfieldType.password.title
    )
    
    private let roadNameAddressTextfield = CommonTextfieldCell(
        title: AuthTextfieldType.roadnameAddress.title
    )
    private let addressSearchButton = MainColorButton(title: "검색")
    
    private let detailedAddressTextfield = CommonTextfieldCell(
        title: AuthTextfieldType.detailedAddress.title
    )
    
    private let editButton = MainColorButton(title: "변경하기")
    
    struct UIConstants {
        static let cellSpacing = 24
        static let cellHeight = 70
        static let buttonHeight = 45
        static let inset = 15
        static let searchButtonWidth = 60
    }
    
    // MARK: - Properties
    
    private let viewModel: UserInfoEditViewModel
    
    private let nicknameTextFieldChanged = BehaviorSubject<String>(value: "")
    private let passwordTextFieldChanged = BehaviorSubject<String>(value: "")
    private let roadNameAddressTextFieldChanged = BehaviorSubject<String>(value: "")
    private let detailAddressTextFieldChanged = BehaviorSubject<String>(value: "")
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Lifecycles
    
    init(viewModel: UserInfoEditViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        bind()
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        title = "회원정보 수정"
        view.backgroundColor = .white
        passwordTextfield.setTextFieldForPassword()
        
        view.addSubview(nicknameTextfield)
        view.addSubview(passwordTextfield)
        view.addSubview(roadNameAddressTextfield)
        view.addSubview(addressSearchButton)
        view.addSubview(detailedAddressTextfield)
        view.addSubview(editButton)
        
        configureUI()
    }
    
    private func configureUI() {
        nicknameTextfield.snp.makeConstraints {
            $0.top.leading.trailing.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset)
            $0.height.equalTo(UIConstants.cellHeight)
        }
        passwordTextfield.snp.makeConstraints {
            $0.top.equalTo(nicknameTextfield.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.height.equalTo(nicknameTextfield)
        }
        roadNameAddressTextfield.snp.makeConstraints {
            $0.top.equalTo(passwordTextfield.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.height.equalTo(nicknameTextfield)
            $0.trailing.equalTo(view.safeAreaLayoutGuide).inset(UIConstants.inset*2 + UIConstants.searchButtonWidth)
        }
        addressSearchButton.snp.makeConstraints {
            $0.bottom.equalTo(roadNameAddressTextfield.snp.bottom)
            $0.leading.equalTo(roadNameAddressTextfield.snp.trailing).offset(UIConstants.inset)
            $0.height.equalTo(UIConstants.buttonHeight)
            $0.width.equalTo(UIConstants.searchButtonWidth)
        }
        detailedAddressTextfield.snp.makeConstraints {
            $0.top.equalTo(roadNameAddressTextfield.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.height.equalTo(nicknameTextfield)
        }
        editButton.snp.makeConstraints {
            $0.top.equalTo(detailedAddressTextfield.snp.bottom).offset(UIConstants.cellSpacing)
            $0.leading.trailing.equalTo(nicknameTextfield)
            $0.height.equalTo(UIConstants.buttonHeight)
        }
    }
    
    private func bind() {
        let input = UserInfoEditViewModel.Input(
            viewWillAppear: rx.methodInvoked(#selector(viewWillAppear(_:))).map{ _ in }.asObservable(),
            nicknameDidChanged: nicknameTextFieldChanged,
            passwordDidChanged: passwordTextFieldChanged,
            roadNameAddressDidChanged: roadNameAddressTextFieldChanged,
            addressSearchButtonDidTapped: addressSearchButton.rx.tap.asObservable(),
            detailAddressDidChanged: detailAddressTextFieldChanged,
            editButtonDidTapped: editButton.rx.tap.asObservable()
        )
        let output = viewModel.transform(input)
        
        bindTextFields()
        
        output.userEditInfo
            .subscribe(onNext: { userInfo in
                DispatchQueue.main.async {
                    self.nicknameTextfield.bind(content: userInfo.nickname)
                    self.roadNameAddressTextfield.bind(content: userInfo.roadnameAddress)
                    self.detailedAddressTextfield.bind(content: userInfo.detailAddress)
                }
            })
            .disposed(by: disposeBag)
        
        output.inputIsValid
            .subscribe(onNext: { [weak self] isValid in
                guard let self else { return }
                editButton.isEnabled = isValid
            })
            .disposed(by: disposeBag)
        
        output.showAlert
            .subscribe(onNext: { [weak self] alertMessage in
                guard let self else { return }
                showAlert(
                    title: alertMessage.title,
                    message: alertMessage.message,
                    type: .oneButton
                )
            })
            .disposed(by: disposeBag)
        
        output.roadnameAddress
            .subscribe(onNext: { [weak self] address in
                guard let self else { return }
                roadNameAddressTextfield.bind(content: address)
            })
            .disposed(by: disposeBag)
    }
    
    private func bindTextFields() {
        nicknameTextfield.textfield.rx.text.orEmpty.asObservable()
            .bind(to: nicknameTextFieldChanged)
            .disposed(by: disposeBag)
        passwordTextfield.textfield.rx.text.orEmpty.asObservable()
            .bind(to: passwordTextFieldChanged)
            .disposed(by: disposeBag)
        roadNameAddressTextfield.textfield.rx.text.orEmpty.asObservable()
            .bind(to: roadNameAddressTextFieldChanged)
            .disposed(by: disposeBag)
        detailedAddressTextfield.textfield.rx.text.orEmpty.asObservable()
            .bind(to: detailAddressTextFieldChanged)
            .disposed(by: disposeBag)
        
        // textfield.text = "" 같은 변화 있을 때 이벤트 발생
        nicknameTextfield.textfield.rx.observe(String.self, "text")
            .map{ $0 ?? "" }
            .bind(to: nicknameTextFieldChanged)
            .disposed(by: disposeBag)
        roadNameAddressTextfield.textfield.rx.observe(String.self, "text")
            .map{ $0 ?? "" }
            .bind(to: roadNameAddressTextFieldChanged)
            .disposed(by: disposeBag)
        detailedAddressTextfield.textfield.rx.observe(String.self, "text")
            .map{ $0 ?? "" }
            .bind(to: detailAddressTextFieldChanged)
            .disposed(by: disposeBag)
    }
}
