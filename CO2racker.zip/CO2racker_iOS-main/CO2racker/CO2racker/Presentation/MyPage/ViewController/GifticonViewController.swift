//
//  GifticonViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import UIKit
import RxSwift

final class GifticonViewController: UIViewController {
    
    // MARK: - UI properties
    
    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = .gifticonImage
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private let imageSaveButton = MainColorButton(title: "앨범에 저장")
    
    private let descriptionLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 18)
        label.textAlignment = .center
        label.textColor = .black
        label.numberOfLines = 0
        label.text = "쿠폰은 [마이페이지 - 내 쿠폰함]에서 확인하실 수 있습니다."
        return label
    }()
    
    // MARK: - Properties
    
    // MARK: - Lifecycles
    
    init(showDescription: Bool) {
        descriptionLabel.isHidden = !showDescription
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        title = "기프티콘"
        view.backgroundColor = .white
        
        view.addSubview(imageView)
        view.addSubview(imageSaveButton)
        view.addSubview(descriptionLabel)
        
        configureUI()
    }
    
    private func configureUI() {
        imageView.snp.makeConstraints {
            $0.top.equalTo(view.safeAreaLayoutGuide).offset(10)
            $0.leading.trailing.equalTo(view.safeAreaLayoutGuide).inset(10)
            $0.height.equalTo(480)
        }
        imageSaveButton.snp.makeConstraints {
            $0.top.equalTo(imageView.snp.bottom).offset(20)
            $0.centerX.equalToSuperview()
            $0.width.equalTo(120)
            $0.height.equalTo(40)
        }
        descriptionLabel.snp.makeConstraints {
            $0.top.equalTo(imageSaveButton.snp.bottom).offset(20)
            $0.leading.trailing.equalTo(view.safeAreaLayoutGuide).inset(20)
        }
    }
}

