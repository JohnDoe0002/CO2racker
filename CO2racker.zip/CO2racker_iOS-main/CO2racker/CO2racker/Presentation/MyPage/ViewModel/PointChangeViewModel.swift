//
//  PointChangeViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

final class PointChangeViewModel {
    
    // MARK: - Input
    
    struct Input {
        let changeButtonDidTapped: Observable<Void>
    }
    
    // MARK: - Output

    struct Output {
        let pointChangeFailure = PublishSubject<String>()
    }
    
    // MARK: - Properties
    
    let showGifticonViewController = PublishSubject<Void>()
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependency
    
    private let usecase: PointChangeUseCaseProtocol
    
    // MARK: - Lifecycles
    
    init(usecase: PointChangeUseCaseProtocol) {
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        input.changeButtonDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                changePoint(changeFailureSubject: output.pointChangeFailure)
            })
            .disposed(by: disposeBag)
        
        return output
    }
    
    private func changePoint(changeFailureSubject: PublishSubject<String>) {
        guard let accessToken = UserDefaults.accessToken else { return }
        
        usecase.changePoint(authorization: accessToken)
            .subscribe(onSuccess: { [weak self] _ in
                guard let self else { return }
                self.showGifticonViewController.onNext(())
            }, onFailure: { error in
                changeFailureSubject.onNext(error.localizedDescription)
            })
            .disposed(by: disposeBag)
    }
}
