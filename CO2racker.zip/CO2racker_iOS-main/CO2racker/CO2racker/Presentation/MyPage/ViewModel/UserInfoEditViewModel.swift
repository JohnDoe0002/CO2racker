//
//  UserInfoEditViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

final class UserInfoEditViewModel {

    // MARK: - Input
    
    struct Input {
        let viewWillAppear: Observable<Void>
        let nicknameDidChanged: BehaviorSubject<String>
        let passwordDidChanged: BehaviorSubject<String>
        let roadNameAddressDidChanged: BehaviorSubject<String>
        let addressSearchButtonDidTapped: Observable<Void>
        let detailAddressDidChanged: BehaviorSubject<String>
        let editButtonDidTapped: Observable<Void>
    }
    
    // MARK: - Output
    
    struct Output {
        let inputIsValid = BehaviorSubject<Bool>(value: false)
        let userEditInfo = PublishSubject<UserEditInfo>()
        let showAlert = PublishSubject<AlertMessageType>()
        let roadnameAddress = PublishSubject<String>()
    }
    
    // MARK: - Properties
    
    let showIndicator = PublishSubject<Bool>()
    let returnToMyPageViewController = PublishSubject<Void>()
    let showPostCodeWebView = PublishSubject<PublishSubject<String>>()
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependency
    
    private let usecase: UserInfoEditUseCaseProtocol
    
    // MARK: - Lifecycles
    
    init(usecase: UserInfoEditUseCaseProtocol) {
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        input.viewWillAppear
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let accessToken = UserDefaults.accessToken else { return }
                
                showIndicator.onNext(true)
                
                usecase.fetchUser(authorization: accessToken)
                    .subscribe(onSuccess: { [weak self] userEditInfo in
                        guard let self else { return }
                        output.userEditInfo.onNext(userEditInfo)
                        showIndicator.onNext(false)
                    }, onFailure: { [weak self] error in
                        guard let self else { return }
                        showIndicator.onNext(false)
                        print(error)
                    })
                    .disposed(by: disposeBag)
            })
            .disposed(by: disposeBag)
        
        Observable.combineLatest(
            input.nicknameDidChanged,
            input.passwordDidChanged,
            input.roadNameAddressDidChanged,
            input.detailAddressDidChanged
        )
        .subscribe(onNext: { [weak self] (nickname, password, roadNameAddress, detailAddress) in
            guard let self else { return }
            let userEditInfo = UserEditInfo(
                nickname: nickname,
                password: password,
                roadnameAddress: roadNameAddress,
                detailAddress: detailAddress
            )
            let isValid = usecase.isValid(userEditInfo)
            output.inputIsValid.onNext(isValid)
        })
        .disposed(by: disposeBag)
        
        input.addressSearchButtonDidTapped
            .subscribe(onNext: { [weak self] _ in
                guard let self else { return }
                showPostCodeWebView.onNext(output.roadnameAddress)
            })
            .disposed(by: disposeBag)
        
        input.editButtonDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                
                guard let accessToken = UserDefaults.accessToken,
                      let nickname = try? input.nicknameDidChanged.value(),
                      let password = try? input.passwordDidChanged.value(),
                      let roadnameAddress = try? input.roadNameAddressDidChanged.value(),
                      let detailAddress = try? input.detailAddressDidChanged.value() else {
                    return
                }
                
                let userEditInfo = UserEditInfo(
                    nickname: nickname,
                    password: password,
                    roadnameAddress: roadnameAddress,
                    detailAddress: detailAddress
                )
                
                showIndicator.onNext(true)
                
                usecase.updateUser(authorization: accessToken, userInfo: userEditInfo)
                    .subscribe(onSuccess: { [weak self] in
                        guard let self else { return }
                        returnToMyPageViewController.onNext(())
                    }, onFailure: { error in
                        output.showAlert.onNext(.userInfoEditFailure(error: error))
                    })
                    .disposed(by: disposeBag)
            })
            .disposed(by: disposeBag)
        
        return output
    }
}
