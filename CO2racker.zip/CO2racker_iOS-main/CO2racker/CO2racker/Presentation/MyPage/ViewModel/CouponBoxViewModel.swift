//
//  CouponBoxViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

final class CouponBoxViewModel {
    
    // MARK: - Input
    
    struct Input {
        let viewWillAppear: Observable<Void>
        let receivedCouponDidTapped: Observable<Int>     // index
    }
    
    // MARK: - Output

    struct Output {
        let receivedCoupon = PublishSubject<[Coupon]>()
        let usedCoupon = PublishSubject<[Coupon]>()
    }
    
    // MARK: - Properties
    
    let showIndicator = PublishSubject<Bool>()
    let showGifticonViewController = PublishSubject<Void>()
    
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependency
    
    private let usecase: CouponBoxUseCaseProtocol
    
    // MARK: - Lifecycles
    
    init(usecase: CouponBoxUseCaseProtocol) {
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        input.viewWillAppear
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let accessToken = UserDefaults.accessToken else { return }
                
                showIndicator.onNext(true)
                
                Single.zip(usecase.fetchReceivedCoupons(authorization: accessToken), usecase.fetchUsedCoupons(authorization: accessToken))
                    .subscribe(onSuccess: { [weak self] (received, used) in
                        guard let self else { return }
                        
                        output.receivedCoupon.onNext(received)
                        output.usedCoupon.onNext(used)
                        
                        showIndicator.onNext(false)
                    })
                    .disposed(by: disposeBag)
                
            })
            .disposed(by: disposeBag)
        
        input.receivedCouponDidTapped
            .subscribe(onNext: { [weak self] _ in
                guard let self else { return }
                showGifticonViewController.onNext(())
            })
            .disposed(by: disposeBag)
        
        return output
    }
}
