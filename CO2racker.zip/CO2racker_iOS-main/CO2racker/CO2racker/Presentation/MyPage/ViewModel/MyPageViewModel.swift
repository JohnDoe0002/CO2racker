//
//  MyPageViewModel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/25.
//

import Foundation
import RxSwift

final class MyPageViewModel {
    
    // MARK: - Input
    
    struct Input {
        let viewWillAppear: Observable<Void>
        let pointChangeDidTapped: Observable<Void>
        let couponBoxDidTapped: Observable<Void>
        let notificationDidTapped: Observable<Void>
        let userInfoEditDidTapped: Observable<Void>
        let logoutDidTapped: Observable<Void>
        let withdrawlDidTapped: Observable<Void>
        let showLoginView: Observable<Void>
    }
    
    // MARK: - Output
    
    struct Output {
        let userInfo = BehaviorSubject<User>(value: User())
        let showAlert = PublishSubject<AlertMessageType>()
    }
    
    // MARK: - Properties
    
    let showIndicator = PublishSubject<Bool>()
    let showPointChangeView = PublishSubject<Void>()
    let showCouponBoxView = PublishSubject<Void>()
    let showUserInfoEditView = PublishSubject<Void>()
    let showLoginViewController = PublishSubject<Void>()
    private let disposeBag = DisposeBag()
    
    // MARK: - Dependencies
    
    private let usecase: MyPageUseCaseProtocol
    
    // MARK: - Lifecycles
    init(usecase: MyPageUseCaseProtocol) {
        self.usecase = usecase
    }
    
    // MARK: - Helpers
    
    func transform(_ input: Input) -> Output {
        let output = Output()
        
        input.viewWillAppear
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                
                showIndicator.onNext(true)
                fetchUserInfo(userInfoSubject: output.userInfo)
            })
            .disposed(by: disposeBag)
        
        input.pointChangeDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showPointChangeView.onNext(())
            })
            .disposed(by: disposeBag)
        
        input.couponBoxDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showCouponBoxView.onNext(())
            })
            .disposed(by: disposeBag)
        
        input.notificationDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                print("notificationDidTapped")
            })
            .disposed(by: disposeBag)
        
        input.userInfoEditDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showUserInfoEditView.onNext(())
            })
            .disposed(by: disposeBag)
        
        input.logoutDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let accessToken = UserDefaults.accessToken else { return }
                
                showIndicator.onNext(true)
                
                usecase.signOut(authorization: accessToken)
                    .subscribe(onSuccess: { [weak self] in
                        guard let self else { return }
                        
                        showIndicator.onNext(false)
                        output.showAlert.onNext(.signOutSuccess)
                    }, onFailure: { [weak self] error in
                        guard let self else { return }
                        
                        showIndicator.onNext(false)
                        output.showAlert.onNext(.signOutFailure(error: error))
                    })
                    .disposed(by: disposeBag)
            })
            .disposed(by: disposeBag)
        
        input.withdrawlDidTapped
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                guard let accessToken = UserDefaults.accessToken else { return }
                
                showIndicator.onNext(true)
                
                usecase.withdrawal(authorization: accessToken)
                    .subscribe(onSuccess: { [weak self] in
                        guard let self else { return }
                        
                        showIndicator.onNext(false)
                        output.showAlert.onNext(.withdrawalSuccess)
                    }, onFailure: { [weak self] error in
                        guard let self else { return }
                        
                        showIndicator.onNext(false)
                        output.showAlert.onNext(.withdrawalFailure(error: error))
                    })
                    .disposed(by: disposeBag)
            })
            .disposed(by: disposeBag)
        
        input.showLoginView
            .subscribe(onNext: { [weak self] in
                guard let self else { return }
                showLoginViewController.onNext(())
            })
            .disposed(by: disposeBag)
        
        return output
    }
    
    private func fetchUserInfo(userInfoSubject: BehaviorSubject<User>) {
        guard let accessToken = UserDefaults.accessToken else { return }
        
        usecase.fetchUserInfo(authorization: accessToken)
            .subscribe(onSuccess: { [weak self] info in
                guard let self else { return }
                
                userInfoSubject.onNext(info)
                
                showIndicator.onNext(false)
            }, onFailure: { error in
                print(error)
            })
            .disposed(by: disposeBag)
    }
}
