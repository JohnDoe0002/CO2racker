//
//  MyPageTableViewCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/25.
//

import UIKit
import SnapKit

final class MyPageCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "MyPageCollectionViewCell"
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = .systemFont(ofSize: 18)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    private func setupViews() {
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints {
            $0.edges.equalToSuperview().inset(17)
        }
    }
    
    func bind(title: String) {
        titleLabel.text = title
    }
}
