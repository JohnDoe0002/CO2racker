//
//  UserInfoView.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/23.
//

import UIKit
import SnapKit

final class UserInfoView: UIView {
    
    // MARK: - UI Properties
    
    private let nicknameLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 24)
        label.textColor = .black
        return label
    }()
    
    private let idLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.textColor = .systemGray1
        return label
    }()
    
    private let pointLabel: UILabel = {
        let label = UILabel()
        label.font = .boldSystemFont(ofSize: 28)
        label.textColor = .mainColor
        label.textAlignment = .right
        return label
    }()
    
    // MARK: - Lifecycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        addSubview(nicknameLabel)
        addSubview(idLabel)
        addSubview(pointLabel)
        
        configureUI()
    }
    
    private func configureUI() {
        nicknameLabel.snp.makeConstraints {
            $0.top.leading.equalToSuperview().inset(20)
            $0.width.equalTo(160)
            $0.height.equalTo(30)
        }
        idLabel.snp.makeConstraints {
            $0.top.equalTo(nicknameLabel.snp.bottom).offset(5)
            $0.leading.width.equalTo(nicknameLabel)
            $0.height.equalTo(20)
        }
        pointLabel.snp.makeConstraints {
            $0.top.equalTo(nicknameLabel)
            $0.leading.equalTo(nicknameLabel.snp.trailing).offset(15)
            $0.trailing.equalToSuperview().inset(20)
            $0.height.equalTo(nicknameLabel)
        }
    }
    
    func bind(_ userInfo: User) {
        nicknameLabel.text = userInfo.nickName + "님"
        idLabel.text = userInfo.userID
        pointLabel.text = String(userInfo.point) + " point"
    }
}
