//
//  CouponCollectionViewCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import UIKit

final class CouponCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "CouponCollectionViewCell"
    
    // MARK: - UI Properties
    
    private let thumbnailImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = .coffeeThumbnailImage
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = .boldSystemFont(ofSize: 16)
        label.text = "스타벅스 카페 아메리카노 T"
        return label
    }()
    
    private let dateLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 14)
        label.text = "2023.06.30 까지"
        return label
    }()
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        layer.cornerRadius = 10
        layer.borderWidth = 1
        layer.borderColor = UIColor.systemGray4.cgColor
        
        addSubview(thumbnailImageView)
        addSubview(titleLabel)
        addSubview(dateLabel)
        
        configureUI()
    }
    
    private func configureUI() {
        thumbnailImageView.snp.makeConstraints {
            $0.top.leading.bottom.equalToSuperview().inset(10)
            $0.width.height.equalTo(70)
        }
        titleLabel.snp.makeConstraints {
            $0.centerY.equalToSuperview().offset(-15)
            $0.leading.equalTo(thumbnailImageView.snp.trailing).offset(10)
            $0.trailing.equalToSuperview().inset(10)
        }
        dateLabel.snp.makeConstraints {
            $0.centerY.equalToSuperview().offset(15)
            $0.leading.trailing.equalTo(titleLabel)
        }
    }

    func bind(thumbnail: UIImage, title: String, date: Date) {
        thumbnailImageView.image = thumbnail
        titleLabel.text = title
        dateLabel.text = date.toStringWithoutTime() + " 까지"
    }
}
