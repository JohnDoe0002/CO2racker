//
//  MyPageCollectionViewHeader.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/25.
//

import UIKit
import SnapKit

final class MyPageCollectionViewHeader: UICollectionReusableView {
    
    static let identifier = "MyPageCollectionViewHeader"
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .systemGray1
        label.font = .systemFont(ofSize: 16)
        return label
    }()

    private let underLineView: UIView = {
        let view = UIView()
        view.backgroundColor = .systemGray1
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    private func setupViews() {
        addSubview(titleLabel)
        addSubview(underLineView)
        
        titleLabel.snp.makeConstraints {
            $0.centerY.equalToSuperview()
            $0.leading.trailing.equalToSuperview().inset(14)
        }
        underLineView.snp.makeConstraints {
            $0.leading.trailing.bottom.equalToSuperview()
            $0.height.equalTo(0.5)
        }
    }
    
    func bind(title: String) {
        titleLabel.text = title
    }
}
