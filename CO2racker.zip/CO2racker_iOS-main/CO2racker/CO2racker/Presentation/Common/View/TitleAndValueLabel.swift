//
//  TitleAndValueLabel.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/03.
//

import UIKit
import SnapKit

final class TitleAndValueLabel: UIView {
    
    // MARK: - UI Properties
    
    private let titleLabel: UILabel = {
        var label = UILabel()
        label.textColor = .black
        label.font = UIFont.boldSystemFont(ofSize: 16)
        label.text = "타이틀"
        return label
    }()
    
    private let valueLabel: UILabel = {
        var label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = "value"
        label.textAlignment = .right
        return label
    }()
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
    }
    
    convenience init(title: String, value: String? = nil) {
        self.init(frame: .zero)
        
        setupViews()
        titleLabel.text = title
        if let value {
            valueLabel.text = value
        }
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        addSubview(titleLabel)
        addSubview(valueLabel)
        
        titleLabel.snp.makeConstraints {
            $0.top.leading.bottom.equalToSuperview()
            $0.width.equalTo(180)
            $0.height.equalTo(22)
        }
        valueLabel.snp.makeConstraints {
            $0.top.trailing.bottom.equalToSuperview()
            $0.width.equalTo(180)
            $0.height.equalTo(22)
        }
    }
    
    func bind(title: String, value: String) {
        titleLabel.text = title
        valueLabel.text = value
    }
    
    func bind(value: String) {
        valueLabel.text = value
    }
}
