//
//  MainColorButton.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/03/28.
//

import UIKit

final class MainColorButton: UIButton {
    
    override var isEnabled: Bool {
        didSet {
            self.alpha = isEnabled ? 1.0: 0.5
        }
    }
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    convenience init(title: String) {
        self.init(frame: CGRect())
        configureUI(title)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Helpers
    
    private func configureUI(_ title: String) {
        setTitle(title, for: .normal)
        setTitleColor(.white, for: .normal)
        
        backgroundColor = .mainColor
        layer.cornerRadius = 10
    }
}
