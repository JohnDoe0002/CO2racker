//
//  CommonTextfieldCell.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/03/27.
//

import UIKit
import SnapKit
import RxSwift

final class CommonTextfieldCell: UICollectionViewCell {
    
    // MARK: - Properties
    
    static let identifier = "CommonTextfieldCell"
    
    // MARK: - UI Properties
    
    private let titleLabel: UILabel = {
        var label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 16)
        label.text = "타이틀"
        return label
    }()
    
    let textfield: UITextField = {
        var textfield = UITextField()
        textfield.layer.borderWidth = 1
        textfield.layer.borderColor = UIColor.black.cgColor
        textfield.layer.cornerRadius = 10
        textfield.addLeftPadding()
        return textfield
    }()
    
    var disposeBag = DisposeBag()
    
    // MARK: - LifeCycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    convenience init(title: String, content: String? = nil, placeholder: String? = nil) {
        self.init(frame: .zero)
        
        titleLabel.text = title
        if let content {
            textfield.text = content
        }
        if let placeholder {
            textfield.placeholder = placeholder
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        disposeBag = DisposeBag()
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        addSubview(titleLabel)
        addSubview(textfield)
        
        titleLabel.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.equalToSuperview().offset(5)
            $0.height.equalTo(20)
        }
        textfield.snp.makeConstraints {
            $0.top.equalTo(titleLabel.snp.bottom).offset(5)
            $0.leading.trailing.equalToSuperview()
            $0.height.equalTo(45)
        }
    }
    
    func bind(title: String? = nil, content: String? = nil, placeholder: String? = nil) {
        if let title {
            titleLabel.text = title
        }
        if let content {
            textfield.text = content
        }
        if let placeholder {
            textfield.placeholder = placeholder
        }
    }
    
    func setTextFieldForPassword() {
        textfield.isSecureTextEntry = true
        textfield.textContentType = .password
    }
}
