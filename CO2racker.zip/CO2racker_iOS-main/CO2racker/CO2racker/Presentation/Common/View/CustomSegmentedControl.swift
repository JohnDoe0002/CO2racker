//
//  UnderlinedSegmentedControl.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/10.
//

import UIKit

final class CustomSegmentedControl: UISegmentedControl {
    
    // MARK: - UI Properties
    private lazy var underlineViews = [UIView]()
    
    // MARK: - Lifecycles
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    override init(items: [Any]?) {
        super.init(items: items)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        updateUnderlineViews()
    }
    
    // MARK: - Helpers
    
    private func setupViews() {
        removeBackgroundAndDivider()
        setTitleTextAttribute()
        createUnderlineViews()
    }
    
    private func removeBackgroundAndDivider() {
        let image = UIImage()
        
        setBackgroundImage(image, for: .normal, barMetrics: .default)
        setBackgroundImage(image, for: .highlighted, barMetrics: .default)
        setBackgroundImage(image, for: .selected, barMetrics: .default)
        setDividerImage(image, forLeftSegmentState: .selected, rightSegmentState: .normal, barMetrics: .default)
    }
    
    private func setTitleTextAttribute() {
        setTitleTextAttributes(
            [.font: UIFont.systemFont(ofSize: 16, weight: .semibold)],
            for: .normal
        )
    }
    
    private func createUnderlineViews() {
        for _ in 0..<numberOfSegments {
            let underlineView = UIView()
            underlineViews.append(underlineView)
            addSubview(underlineView)
        }
    }
    
    private func updateUnderlineViews() {
        let segmentWidth = bounds.width / CGFloat(numberOfSegments)
        let y = bounds.size.height - 1.0
        
        UIView.animate(withDuration: 0.1, animations: {
            for i in 0..<self.underlineViews.count {
                self.underlineViews[i].backgroundColor = .systemGray4
                
                let x = CGFloat(i) * segmentWidth
                self.underlineViews[i].frame = CGRect(x: x, y: y, width: segmentWidth-1, height: 1.0)
            }
            self.underlineViews[self.selectedSegmentIndex].backgroundColor = .mainColor
        })
    }
}
