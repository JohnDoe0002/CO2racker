//
//  PostCodeWebViewController.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/29.
//

import UIKit
import WebKit
import SnapKit
import RxSwift

final class PostCodeWebViewController: UIViewController {
    
    // MARK: - UI properties
    
    private var webView: WKWebView?
    
    // MARK: - Properties
    
    let addressData: PublishSubject<String>
    
    // MARK: - Lifecycles
    
    init(_ addressData: PublishSubject<String>) {
        self.addressData = addressData
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupWebView()
    }
    
    // MARK: - Helpers
    
    private func setupWebView() {
        let contentController = WKUserContentController()
        contentController.add(self, name: "callBackHandler")
        
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = contentController
        
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView?.navigationDelegate = self
        
        configureUI()
        loadWebView()
    }
    
    private func loadWebView() {
        guard let url = URL(string: "https://sangyeon3.github.io/Kakao-PostCode/"),
              let webView else {
            return
        }
        let request = URLRequest(url: url)
        webView.load(request)
    }
    
    private func configureUI() {
        guard let webView else { return }
        view.addSubview(webView)
        webView.snp.makeConstraints {
            $0.edges.equalTo(view.safeAreaLayoutGuide)
        }
    }
}

// MARK: - WKScriptMessageHandler

extension PostCodeWebViewController: WKScriptMessageHandler {
    
    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        var address: String? = nil
        if let data = message.body as? [String: Any] {
            address = data["roadAddress"] as? String
        }
        addressData.onNext(address ?? "")
        self.dismiss(animated: true)
    }
}

// MARK: - WKNavigationDelegate

// TODO: - Delegate Proxy 전환

extension PostCodeWebViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        showIndicator()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        hideIndicator()
    }
}
