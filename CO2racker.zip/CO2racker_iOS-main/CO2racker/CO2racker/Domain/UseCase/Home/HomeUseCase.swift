//
//  HomeUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/18.
//

import Foundation
import RxSwift

enum HomeUseCaseError: Error {
    case notExistSelf
}

final class HomeUseCase: HomeUseCaseProtocol {
    
    private let consumptionRepository: ConsumptionRepositoryProtocol
    private let userRepository: UserRepositoryProtocol

    private let disposeBag = DisposeBag()
    
    init(consumptionRepository: ConsumptionRepositoryProtocol, userRepository: UserRepositoryProtocol) {
        self.consumptionRepository = consumptionRepository
        self.userRepository = userRepository
    }
    
    func fetchConsumptionData(authorization: String) -> Single<[Consumption]> {
        let consumptionSingleArray = Array<EnergyType>([.power, .water, .gas]).map {
            self.fetchConsumptionData(authorization: authorization, energyType: $0)
        }
        return Single.zip(consumptionSingleArray)
    }
    
    func fetchUserArea(authorization: String) -> Single<String> {
        userRepository.fetchUserInfo(authorization: authorization)
            .map{ user in user.address }
    }
    
    func fetchCO2(authorization: String) -> Single<Double> {
        consumptionRepository.fetchCO2(authorization: authorization)
    }
    
    private func fetchConsumptionData(authorization: String, energyType type: EnergyType) -> Single<Consumption> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(HomeUseCaseError.notExistSelf))
                return Disposables.create()
            }
            
            self.consumptionRepository.fetchConsumptionData(authorization: authorization, energyType: type)
                .subscribe (onSuccess: {
                    single(.success($0))
                }, onFailure: { error in
                    if let error = error as? ConsumptionRepositoryError,
                       case .notExistData = error {
                        single(.success(Consumption(type: type)))
                    } else {
                        single(.failure(error))
                    }
                })
                .disposed(by: disposeBag)
            
            return Disposables.create()
        }
    }
}
