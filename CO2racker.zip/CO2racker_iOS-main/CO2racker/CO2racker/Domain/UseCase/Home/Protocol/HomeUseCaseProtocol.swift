//
//  HomeUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/18.
//

import Foundation
import RxSwift

protocol HomeUseCaseProtocol {
    /// 전기, 수도, 가스 데이터 가져옴
    func fetchConsumptionData(authorization: String) -> Single<[Consumption]>
    /// 사용자 지역구
    func fetchUserArea(authorization: String) -> Single<String>
    /// CO2 발생량
    func fetchCO2(authorization: String) -> Single<Double>
}
