//
//  LoginUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation
import RxSwift

enum LoginError: LocalizedError {
    case notExistSelf
    case loginFailure((statusCode: Int, message: String))
    
    public var errorDescription: String? {
        switch self {
        case .notExistSelf:
            return "LoginError: notExistSelf"
        case .loginFailure((let statusCode, let message)):
            return "[Error \(statusCode)] \(message)"
        }
    }
}

final class LoginUseCase: LoginUseCaseProtocol {
    
    private let authRepository: AuthRepositoryProtocol
    private let disposeBag = DisposeBag()
    
    init(authRepository: AuthRepositoryProtocol) {
        self.authRepository = authRepository
    }
    
    func isValid(_ email: String, _ password: String) -> Bool {
        !email.isEmpty && !password.isEmpty
    }
    
    func login(_ email: String, _ password: String) -> Single<Void> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(LoginError.notExistSelf))
                return Disposables.create()
            }
            
            let loginInfo = LoginInfo(userID: email, password: password)
            
            authRepository.logIn(loginInfo: loginInfo)
                .subscribe(onSuccess: { accessToken in
                    UserDefaults.accessToken = accessToken
                    single(.success(()))
                }, onFailure: { error in
                    if let error = error as? NetworkError,
                       case let .invalidStatusCodeError((statusCode, message)) = error {
                        single(.failure(LoginError.loginFailure((statusCode, message))))
                    }
                    single(.failure(error))
                })
                .disposed(by: disposeBag)
                        
            return Disposables.create()
        }
    }
}
