//
//  SignUpBasicInfoUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation
import RxSwift

enum SignUpError: LocalizedError {
    case notExistSelf
    case signUpFailure((statusCode: Int, message: String))
    
    public var errorDescription: String? {
        switch self {
        case .notExistSelf:
            return "SignUpError: notExistSelf"
        case .signUpFailure((let statusCode, let message)):
            return "[Error \(statusCode)] \(message)"
        }
    }
}

final class SignUpUseCase: SignUpUseCaseProtocol {
    
    private let authRepository: AuthRepositoryProtocol
    private let disposeBag = DisposeBag()
    
    init(authRepository: AuthRepositoryProtocol) {
        self.authRepository = authRepository
    }
    
    func isValid(_ email: String, _ password: String, _ nickname: String, _ roadNameAddress: String) -> Bool {
        !email.isEmpty && !password.isEmpty && !nickname.isEmpty && !roadNameAddress.isEmpty
    }
    
    func signUp(_ signUpInfo: SignUpInfo) -> Single<Void> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(SignUpError.notExistSelf))
                return Disposables.create()
            }
            
            authRepository.signUp(signUpInfo: signUpInfo)
                .subscribe(onSuccess: { _ in
                    single(.success(()))
                }, onFailure: { error in
                    if let error = error as? NetworkError,
                       case let .invalidStatusCodeError((statusCode, message)) = error {
                        single(.failure(SignUpError.signUpFailure((statusCode, message))))
                    }
                    single(.failure(error))
                })
                .disposed(by: disposeBag)
                
            return Disposables.create()
        }
    }
}
