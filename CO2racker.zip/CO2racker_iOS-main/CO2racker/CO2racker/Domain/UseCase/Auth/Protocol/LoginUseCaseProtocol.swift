//
//  LoginUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation
import RxSwift

protocol LoginUseCaseProtocol {
    func isValid(_ email: String, _ password: String) -> Bool
    func login(_ email: String, _ password: String) -> Single<Void>
}
