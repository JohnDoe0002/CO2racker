//
//  SignUpBasicInfoUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation
import RxSwift

protocol SignUpUseCaseProtocol {
    func isValid(_ email: String, _ password: String, _ nickname: String, _ roadNameAddress: String) -> Bool
    func signUp(_ signUpInfo: SignUpInfo) -> Single<Void>
}
