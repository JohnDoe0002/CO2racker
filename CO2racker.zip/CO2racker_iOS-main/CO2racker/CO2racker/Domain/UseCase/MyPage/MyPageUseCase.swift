//
//  MyPageUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/25.
//

import Foundation
import RxSwift

enum MyPageError: LocalizedError {
    case notExistSelf
    case signOutFailure((statusCode: Int, message: String))
    case withdrawalFailure((statusCode: Int, message: String))
    
    public var errorDescription: String? {
        switch self {
        case .notExistSelf:
            return "MyPageError: notExistSelf"
        case .signOutFailure((let statusCode, let message)):
            return "[Error \(statusCode)] \(message)"
        case .withdrawalFailure((let statusCode, let message)):
            return "[Error \(statusCode)] \(message)"
        }
    }
}

final class MyPageUseCase: MyPageUseCaseProtocol {
    
    private let userRepository: UserRepositoryProtocol
    private let authRepository: AuthRepositoryProtocol
    
    private let disposeBag = DisposeBag()
    
    init(userRepository: UserRepositoryProtocol, authRepository: AuthRepositoryProtocol) {
        self.userRepository = userRepository
        self.authRepository = authRepository
    }
    
    func fetchUserInfo(authorization: String) -> Single<User> {
        userRepository.fetchUserInfo(authorization: authorization)
    }
    
    func signOut(authorization: String) -> Single<Void> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(MyPageError.notExistSelf))
                return Disposables.create()
            }
            
            authRepository.signOut(authorization: authorization)
                .subscribe(onSuccess: {
                    single(.success(()))
                }, onFailure: { error in
                    if let error = error as? NetworkError,
                       case let .invalidStatusCodeError((statusCode, message)) = error {
                        single(.failure(MyPageError.signOutFailure((statusCode, message))))
                    }
                    single(.failure(error))
                })
                .disposed(by: disposeBag)
            
            return Disposables.create()
        }
    }
    
    func withdrawal(authorization: String) -> Single<Void> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(MyPageError.notExistSelf))
                return Disposables.create()
            }
            
            authRepository.withdrawal(authorization: authorization)
                .subscribe(onSuccess: {
                    single(.success(()))
                }, onFailure: { error in
                    if let error = error as? NetworkError,
                       case let .invalidStatusCodeError((statusCode, message)) = error {
                        single(.failure(MyPageError.withdrawalFailure((statusCode, message))))
                    }
                    single(.failure(error))
                })
                .disposed(by: disposeBag)
            
            return Disposables.create()
        }
    }
}
