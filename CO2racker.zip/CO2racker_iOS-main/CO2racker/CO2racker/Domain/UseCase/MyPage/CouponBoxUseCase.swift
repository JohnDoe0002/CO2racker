//
//  CouponBoxUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

final class CouponBoxUseCase: CouponBoxUseCaseProtocol {
    
    private let userRepository: UserRepositoryProtocol
    private let disposeBag = DisposeBag()
    
    init(userRepository: UserRepositoryProtocol) {
        self.userRepository = userRepository
    }
    
    func fetchReceivedCoupons(authorization: String) -> Single<[Coupon]> {
        userRepository.fetchUserInfo(authorization: authorization)
            .map { user in
                Array(0..<user.gifticonCount).map { _ in
                    Coupon(title: "", imageURL: "coffee_thumbnail", date: Date())
                }
            }
    }
    
    func fetchUsedCoupons(authorization: String) -> Single<[Coupon]> {
        Single.just(1)
            .map { count in
                Array(0..<count).map { _ in
                    Coupon(title: "", imageURL: "coffee_thumbnail", date: Date())
                }
            }
    }


}
