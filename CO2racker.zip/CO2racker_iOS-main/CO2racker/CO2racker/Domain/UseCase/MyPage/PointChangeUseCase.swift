//
//  PointChangeUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

enum PointChangeError: LocalizedError {
    case notExistSelf
    case pointChangeFailure((statusCode: Int, message: String))
    
    public var errorDescription: String? {
        switch self {
        case .notExistSelf:
            return "LoginError: notExistSelf"
        case .pointChangeFailure((let statusCode, let message)):
            return "[Error \(statusCode)] \(message)"
        }
    }   
}

final class PointChangeUseCase: PointChangeUseCaseProtocol {
    
    private let gifticonRepository: GifticonRepositoryProtocol
    
    private let disposeBag = DisposeBag()
    
    init(gifticonRepository: GifticonRepositoryProtocol) {
        self.gifticonRepository = gifticonRepository
    }
    
    func changePoint(authorization: String) -> Single<Void> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(PointChangeError.notExistSelf))
                return Disposables.create()
            }
            
            gifticonRepository.buyGifticon(authorization: authorization)
                .subscribe(onSuccess: { _ in
                    single(.success(()))
                }, onFailure: { error in
                    if let error = error as? NetworkError,
                       case let .invalidStatusCodeError((statusCode, message)) = error {
                        single(.failure(
                            PointChangeError.pointChangeFailure((statusCode, message))
                        ))
                    }
                    single(.failure(error))
                })
                .disposed(by: disposeBag)
            
            return Disposables.create()
        }
    }
}
