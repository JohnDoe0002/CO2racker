//
//  UserInfoEditUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

protocol UserInfoEditUseCaseProtocol {
    func isValid(_ userEditInfo: UserEditInfo) -> Bool
    func fetchUser(authorization: String) -> Single<UserEditInfo>
    func updateUser(authorization: String, userInfo: UserEditInfo) -> Single<Void>
}
