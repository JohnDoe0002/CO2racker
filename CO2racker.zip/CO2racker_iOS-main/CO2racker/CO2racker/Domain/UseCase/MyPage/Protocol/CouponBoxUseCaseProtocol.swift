//
//  CouponBoxUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

protocol CouponBoxUseCaseProtocol {
    func fetchReceivedCoupons(authorization: String) -> Single<[Coupon]>
    func fetchUsedCoupons(authorization: String) -> Single<[Coupon]>
}
