//
//  PointChangeUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

protocol PointChangeUseCaseProtocol {
    func changePoint(authorization: String) -> Single<Void>
}
