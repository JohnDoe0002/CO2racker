//
//  MyPageUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/25.
//

import Foundation
import RxSwift

protocol MyPageUseCaseProtocol {
    func fetchUserInfo(authorization: String) -> Single<User>
    func signOut(authorization: String) -> Single<Void>
    func withdrawal(authorization: String) -> Single<Void>
}
