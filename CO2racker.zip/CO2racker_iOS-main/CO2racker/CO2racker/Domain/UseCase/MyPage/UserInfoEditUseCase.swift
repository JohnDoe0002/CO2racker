//
//  UserInfoEditUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation
import RxSwift

enum UserInfoEditError: LocalizedError {
    case notExistSelf
    case userUpdateFailure((statusCode: Int, message: String))
    
    public var errorDescription: String? {
        switch self {
        case .notExistSelf:
            return "UserInfoEditError: notExistSelf"
        case .userUpdateFailure((let statusCode, let message)):
            return "[Error \(statusCode)] \(message)"
        }
    }
}

final class UserInfoEditUseCase: UserInfoEditUseCaseProtocol {
    
    private let userRepository: UserRepositoryProtocol
    private let disposeBag = DisposeBag()
    
    init(userRepository: UserRepositoryProtocol) {
        self.userRepository = userRepository
    }
    
    func isValid(_ userEditInfo: UserEditInfo) -> Bool {
        !userEditInfo.nickname.isEmpty && !userEditInfo.password.isEmpty && !userEditInfo.roadnameAddress.isEmpty && !userEditInfo.detailAddress.isEmpty
    }
    
    func fetchUser(authorization: String) -> Single<UserEditInfo> {
        userRepository.fetchUserInfo(authorization: authorization)
            .map { user in
                UserEditInfo(
                    nickname: user.nickName,
                    password: "",
                    roadnameAddress: user.address,
                    detailAddress: user.detailAddress
                )
            }
    }
    
    func updateUser(authorization: String, userInfo: UserEditInfo) -> Single<Void> {
        Single.create { [weak self] single in
            guard let self else {
                single(.failure(UserInfoEditError.notExistSelf))
                return Disposables.create()
            }
            
            userRepository.updateUser(authorization: authorization, userEditInfo: userInfo)
                .subscribe(onSuccess: {
                    single(.success(()))
                }, onFailure: { error in
                    if let error = error as? NetworkError,
                       case let .invalidStatusCodeError((statusCode, message)) = error {
                        single(.failure(UserInfoEditError.userUpdateFailure((statusCode, message))))
                    }
                    single(.failure(error))
                })
                .disposed(by: disposeBag)
            
            return Disposables.create()
        }
    }
}
