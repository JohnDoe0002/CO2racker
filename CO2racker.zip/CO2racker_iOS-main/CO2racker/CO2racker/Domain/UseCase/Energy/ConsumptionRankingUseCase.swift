//
//  ConsumptionRankingUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import Foundation
import RxSwift

final class ConsumptionRankingUseCase: ConsumptionRankingUseCaseProtocol {
    
    private let consumptionRepository: ConsumptionRepositoryProtocol
    
    init(consumptionRepository: ConsumptionRepositoryProtocol) {
        self.consumptionRepository = consumptionRepository
    }
    
    func fetchRanking(authorization: String, energyType: EnergyType) -> Single<[RankInfo]> {
        consumptionRepository.fetchConsumptionRanking(authorization: authorization, energyType: energyType)
    }
}
