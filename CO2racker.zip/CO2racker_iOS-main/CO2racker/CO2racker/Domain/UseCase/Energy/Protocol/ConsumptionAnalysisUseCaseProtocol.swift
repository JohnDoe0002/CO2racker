//
//  AnalysisUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/15.
//

import Foundation
import RxSwift

protocol ConsumptionAnalysisUseCaseProtocol {
    func fetchConsumptionData(authorization: String, energyType: EnergyType) -> Single<Consumption?>
}
