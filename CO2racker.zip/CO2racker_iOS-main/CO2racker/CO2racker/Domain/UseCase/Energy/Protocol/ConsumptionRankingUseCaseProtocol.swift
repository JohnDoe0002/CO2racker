//
//  ConsumptionRankingUseCaseProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import Foundation
import RxSwift

protocol ConsumptionRankingUseCaseProtocol {
    func fetchRanking(authorization: String, energyType: EnergyType) -> Single<[RankInfo]>
}
