//
//  AnalysisUseCase.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/15.
//

import Foundation
import RxSwift

final class ConsumptionAnalysisUseCase: ConsumptionAnalysisUseCaseProtocol {
    
    private let consumptionRepository: ConsumptionRepositoryProtocol
    
    private let disposeBag = DisposeBag()
    
    init(consumptionRepository: ConsumptionRepositoryProtocol) {
        self.consumptionRepository = consumptionRepository
    }
    
    func fetchConsumptionData(authorization: String, energyType: EnergyType) -> Single<Consumption?> {
        Single.create { [weak self] single in
            guard let self else {
                return Disposables.create()
            }
            self.consumptionRepository.fetchConsumptionData(authorization: authorization, energyType: energyType)
                .subscribe(onSuccess: {
                    single(.success($0))
                }, onFailure: { error in
                    if let error = error as? ConsumptionRepositoryError,
                       case .notExistData = error {
                        single(.success(nil))
                    } else {
                        single(.failure(error))
                    }
                })
                .disposed(by: self.disposeBag)
            return Disposables.create()
        }
    }
}
