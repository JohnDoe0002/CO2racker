//
//  RankInfo.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import Foundation

struct RankInfo {
    let type: EnergyType
    let rank: Int
    let nickname: String
    let consumption: Int
    
    init(type: EnergyType = .power, rank: Int = -1, nickname: String = "기록없음", consumption: Int = -1) {
        self.type = type
        self.rank = rank
        self.nickname = nickname
        self.consumption = consumption
    }
}
