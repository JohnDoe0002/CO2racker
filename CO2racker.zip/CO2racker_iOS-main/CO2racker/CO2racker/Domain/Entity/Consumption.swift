//
//  Consumption.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/16.
//

import Foundation

struct Consumption {
    let type: EnergyType
    let consumption: Int
    let rank: Int
    let rankAgainstPrevMonth: Int
    let area: String
    let totalHouseholds: Int
    let consumptionGraphData: [ConsumptionGraphDatum]
    let updatedAt: Date
    
    init(
        type: EnergyType,
        consumption: Int = -1,
        rank: Int = -1,
        rankAgainstPrevMonth: Int = -1,
        area: String = "",
        totalHouseholds: Int = -1,
        consumptionGraphData: [ConsumptionGraphDatum] = [],
        updatedAt: Date = Date()
    ) {
        self.type = type
        self.consumption = consumption
        self.rank = rank
        self.rankAgainstPrevMonth = rankAgainstPrevMonth
        self.area = area
        self.totalHouseholds = totalHouseholds
        self.consumptionGraphData = consumptionGraphData
        self.updatedAt = updatedAt
    }
}

struct ConsumptionGraphDatum {
    let createdAt: String
    let consumption: Int
}
