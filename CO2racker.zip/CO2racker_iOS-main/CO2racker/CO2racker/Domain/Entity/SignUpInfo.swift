//
//  SignUpInfo.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/23.
//

import Foundation

struct SignUpInfo {
    let userID: String
    let password: String
    var nickName: String
    var address: String
    var detailAddress: String
}
