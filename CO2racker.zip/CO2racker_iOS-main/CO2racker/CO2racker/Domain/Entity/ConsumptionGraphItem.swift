//
//  ConsumptionGraphItem.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/30.
//

import Foundation

struct ConsumptionGraphItem {
    let amount: Int
    let hour: Int
}
