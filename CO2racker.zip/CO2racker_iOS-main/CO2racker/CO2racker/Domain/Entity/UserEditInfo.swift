//
//  UserEditInfo.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/31.
//

import Foundation

struct UserEditInfo {
    let nickname: String
    let password: String
    let roadnameAddress: String
    let detailAddress: String
}
