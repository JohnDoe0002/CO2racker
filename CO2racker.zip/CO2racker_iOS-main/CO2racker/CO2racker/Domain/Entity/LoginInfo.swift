//
//  LoginInfo.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation

struct LoginInfo {
    let userID: String
    let password: String
}
