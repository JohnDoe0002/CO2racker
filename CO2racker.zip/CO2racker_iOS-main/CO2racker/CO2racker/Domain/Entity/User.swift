//
//  User.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/08.
//

import Foundation

struct User {
    let userID: String
    var nickName: String
    var address: String
    var detailAddress: String
    var point: Int
    var gifticonCount: Int
    
    init(userID: String, nickName: String, address: String, detailAddress: String, point: Int, gifticonCount: Int) {
        self.userID = userID
        self.nickName = nickName
        self.address = address
        self.detailAddress = detailAddress
        self.point = point
        self.gifticonCount = gifticonCount
    }
    
    init() {
        self.init(userID: "a@a.com", nickName: "User", address: "미추홀구", detailAddress: "인하대학교", point: 0, gifticonCount: 0)
    }
}
