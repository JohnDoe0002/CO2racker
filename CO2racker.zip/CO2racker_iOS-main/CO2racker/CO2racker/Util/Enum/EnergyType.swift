//
//  UsageType.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/10.
//

import Foundation

enum EnergyType: String {
    case power = "ELEC"
    case water = "WATER"
    case gas = "GAS"
    
    var title: String {
        switch self{
        case .power:
            return "전기"
        case .water:
            return "수도"
        case .gas:
            return "가스"
        }
    }
    
    var unit: String {
        switch self{
        case .power:
            return "kWh"
        case .water:
            return "m³"
        case .gas:
            return "m³"
        }
    }
    
    var queryString: String {
        return self.rawValue
    }
    
    var dailyMaxAmount: CGFloat {
        switch self {
        case .power:    // 4인 가구 평균 10
            return 50
        case .water:    // 4인 가구 평균 150
            return 500
        case .gas:      // 4인 가구 평균 66
            return 200
        }
    }
}
