//
//  AnalysisLabelType.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/15.
//

import Foundation

enum AnalysisLabelType: Int, CaseIterable {
    case consumption
    case realtimeRank
    case rankAgainstPrevMonth
    
    var title: String {
        switch self {
        case .consumption:
            return "이번 달 소비량"
        case .realtimeRank:
            return "실시간 절약 랭킹"
        case .rankAgainstPrevMonth:
            return "지난 달 대비 절약 랭킹"
        }
    }
    
    
}
