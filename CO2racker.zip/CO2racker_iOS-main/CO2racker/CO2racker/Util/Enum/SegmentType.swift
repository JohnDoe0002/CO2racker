//
//  SegmentType.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/10.
//

import Foundation

enum ConsumptionSegmentType: Int, CaseIterable {
    case analysis
    case ranking
    
    var title: String {
        switch self {
        case .analysis:
            return "분석"
        case .ranking:
            return "랭킹"
        }
    }
    
    var index: Int {
        return self.rawValue
    }
}

enum CouponBoxSegmentType: Int, CaseIterable {
    case received
    case used

    var title: String {
        switch self {
        case .received:
            return "받은 쿠폰"
        case .used:
            return "사용/만료 쿠폰"
        }
    }

    var index: Int {
        return self.rawValue
    }
}
