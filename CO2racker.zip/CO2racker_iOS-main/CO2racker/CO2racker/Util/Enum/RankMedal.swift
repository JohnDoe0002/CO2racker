//
//  RankMedal.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import UIKit

enum RankMedal: Int {
    case gold
    case silver
    case bronze
    
    var image: UIImage {
        switch self {
        case .gold:
            return .goldMedal
        case .silver:
            return .silverMedal
        case .bronze:
            return .bronzeMedal
        }
    }
}
