//
//  AlertMessageType.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation

enum AlertMessageType {
    case loginFailure(error: Error)
    case signUpSuccess
    case signUpFailure(error: Error)
    case reconfirmSignOut
    case signOutSuccess
    case signOutFailure(error: Error)
    case reconfirmWithdrawal
    case withdrawalSuccess
    case withdrawalFailure(error: Error)
    case pointChange
    case pointChangeFailure
    case userInfoEditFailure(error: Error)
    
    var title: String {
        switch self {
        case .loginFailure:
            return "로그인에 실패했습니다."
        case .signUpSuccess:
            return "회원가입에 성공했습니다."
        case .signUpFailure:
            return "회원가입에 실패했습니다."
        case .reconfirmSignOut:
            return "로그아웃 하시겠습니까?"
        case .signOutSuccess:
            return "로그아웃 되었습니다."
        case .signOutFailure:
            return "로그아웃에 실패했습니다."
        case .reconfirmWithdrawal:
            return "정말 탈퇴하시겠습니까?"
        case .withdrawalSuccess:
            return "탈퇴 되었습니다."
        case .withdrawalFailure:
            return "탈퇴에 실패했습니다."
        case .pointChange:
            return "기프티콘으로 전환하시겠습니까?"
        case .pointChangeFailure:
            return "포인트 전환에 실패했습니다."
        case .userInfoEditFailure:
            return "회원정보 수정에 실패했습니다."
        }
    }
    
    var message: String? {
        switch self {
        case .loginFailure(let error):
            return error.localizedDescription
        case .signUpSuccess:
            return "다시 로그인해주세요."
        case .signUpFailure(let error):
            return error.localizedDescription
        case .signOutFailure(let error):
            return error.localizedDescription
        case .withdrawalFailure(let error):
            return error.localizedDescription
        case .pointChange:
            return "5000 포인트가 차감됩니다."
        case .userInfoEditFailure(let error):
            return error.localizedDescription
        default:
            return nil
        }
    }
}
