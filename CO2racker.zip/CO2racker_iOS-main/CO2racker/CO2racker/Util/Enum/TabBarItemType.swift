//
//  TabBarItemType.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/22.
//

import Foundation

enum TabBarItemType: Int, CaseIterable {
    case home
    case power
    case water
    case gas
    case setting
    
    var title: String {
        switch self {
        case .home:
            return "홈"
        case .power:
            return "전기"
        case .water:
            return "수도"
        case .gas:
            return "가스"
        case .setting:
            return "마이페이지"
        }
    }
    
    var itemImageSystemName: String {
        switch self {
        case .home:
            return "house.fill"
        case .power:
            return "bolt.fill"
        case .water:
            return "drop.fill"
        case .gas:
            return "flame.fill"
        case .setting:
            return "person.fill"
        }
    }
}
