//
//  Co2rackerNetworkAPI.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/09.
//

import Foundation

// "http://localhost:8080/auth/sign-up"

enum Co2rackerNetworkAPI {
    case signUp
    case signIn
    case signOut
    case withdrawal
    case consumption
    case consumptionRanking
    case co2
    case userInfo
    case updateUser
    case gifticon
    
    static func headers(authorization: String? = nil) -> [String: String] {
        if let authorization {
            return ["Content-Type": "application/json", "accept": "*/*", "Authorization": ("Bearer " + authorization)]
        }
        return ["Content-Type": "application/json", "accept": "*/*"]
    }
    
    static let baseURL = "https://coracker-back-qvwwk.run.goorm.io"
    
    var url: String {
        switch self {
        case .signUp:
            return Co2rackerNetworkAPI.baseURL + "/auth/sign-up"
        case .signIn:
            return Co2rackerNetworkAPI.baseURL + "/auth/sign-in"
        case .signOut:
            return Co2rackerNetworkAPI.baseURL + "/auth/sign-out"
        case .withdrawal:
            return Co2rackerNetworkAPI.baseURL + "/auth/withdrawal"
        case .consumption:
            return Co2rackerNetworkAPI.baseURL + "/consumption"
        case .consumptionRanking:
            return Co2rackerNetworkAPI.baseURL + "/consumption/ranking"
        case .co2:
            return Co2rackerNetworkAPI.baseURL + "/consumption/co2"
        case .userInfo:
            return Co2rackerNetworkAPI.baseURL + "/user/info"
        case .updateUser:
            return Co2rackerNetworkAPI.baseURL + "/user/update"
        case .gifticon:
            return Co2rackerNetworkAPI.baseURL + "/gifticon"
        }
    }
}
