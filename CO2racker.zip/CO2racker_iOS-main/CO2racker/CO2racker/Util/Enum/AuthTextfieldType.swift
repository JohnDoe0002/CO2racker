//
//  AuthTextfieldType.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/03/28.
//

import Foundation

enum AuthTextfieldType: Int, CaseIterable {
    case email
    case password
    case nickname
    case roadnameAddress
    case detailedAddress
    
    var title: String {
        switch self {
        case .email:
            return "이메일"
        case .password:
            return "비밀번호"
        case .nickname:
            return "닉네임"
        case .roadnameAddress:
            return "도로명 주소"
        case .detailedAddress:
            return "상세주소"
        }
    }
    
    var placeholder: String {
        switch self {
        case .email:
            return "이메일을 입력해주세요."
        case .password:
            return "비밀번호를 입력해주세요."
        case .nickname:
            return "닉네임을 입력해주세요."
        case .roadnameAddress:
            return "도로명 주소를 입력해주세요."
        case .detailedAddress:
            return "상세주소를 입력해주세요. (선택)"
        }
    }
}
