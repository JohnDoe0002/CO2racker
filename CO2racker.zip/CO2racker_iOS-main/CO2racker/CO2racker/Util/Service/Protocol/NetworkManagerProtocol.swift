//
//  NetworkManagerProtocol.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/09.
//

import Foundation
import RxSwift

protocol NetworkManagerProtocol {
    
    func request<T: Decodable>(
        urlString: String,
        method: HTTPMethod,
        headers: [String: String]?,
        parameters: HTTPParameter?
    ) -> Single<T>
}
