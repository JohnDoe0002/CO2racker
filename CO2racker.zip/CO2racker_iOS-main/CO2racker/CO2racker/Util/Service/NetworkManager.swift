//
//  NetworkManager.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/09.
//

import Foundation
import RxSwift

enum HTTPMethod: String {
    case GET, POST, DELETE, PATCH
}

enum HTTPParameter {
    case query([String: String])
    case body(Encodable)
}

enum NetworkError: Error {
    case JSONEncodeError
    case URLError
    case URLSessionError(description: String)
    case HTTPResponseError
    case invalidStatusCodeError((statusCode: Int, message: String))
    case decodeError
}

struct InvalidStatusCodeErrorData: Decodable {
    let message: String
}

final class NetworkManager: NetworkManagerProtocol {
    
    static let shared = NetworkManager()
    
    private init() {}
    
    func request<T: Decodable>(
        urlString: String,
        method: HTTPMethod,
        headers: [String: String]?,
        parameters: HTTPParameter?
    ) -> Single<T> {
        Single.create { single in
            
            // MARK: - RequestURL
            
            guard let urlComponents = URLComponents(string: urlString),
                  var url = urlComponents.url else {
                single(.failure(NetworkError.URLError))
                return Disposables.create()
            }
            
            // MARK: - Queries
            if let parameters, case .query(let queries) = parameters {
                url.append(queryItems: queries.map { URLQueryItem(name: $0.key, value: $0.value)})
            }
            
            var requestURL = URLRequest(url: url)
            requestURL.httpMethod = method.rawValue
            
            // MARK: - Headers
            
            if let headers {
                headers.forEach {
                    requestURL.addValue($0.value, forHTTPHeaderField: $0.key)
                }
            }
            
            // MARK: - Parameters
            
            if let parameters, case .body(let body) = parameters {
                guard let jsonData = try? JSONEncoder().encode(body) else {
                    single(.failure(NetworkError.JSONEncodeError))
                    return Disposables.create()
                }
                requestURL.httpBody = jsonData
            }
            
            // MARK: - URLSession
            
            let urlSession = URLSession(configuration: .default)
            let dataTask = urlSession.dataTask(with: requestURL) { (data, response, error) in
                if let error {
                    single(.failure(NetworkError.URLSessionError(description: error.localizedDescription)))
                    return
                }
                
                guard let response = response as? HTTPURLResponse,
                      let data else {
                    single(.failure(NetworkError.HTTPResponseError))
                    return
                }
                
                let successRange = 200..<300
                if !successRange.contains(response.statusCode) {
                    guard let errorMessage = try? JSONDecoder().decode(InvalidStatusCodeErrorData.self, from: data) else {
                        single(.failure(NetworkError.invalidStatusCodeError((statusCode: response.statusCode, message: ""))))
                        return
                    }
                    single(.failure(NetworkError.invalidStatusCodeError((statusCode: response.statusCode, message: errorMessage.message))))
                    return
                }
                
                // Decoding
                guard let decodedData = try? JSONDecoder().decode(T.self, from: data) else {
                    single(.failure(NetworkError.decodeError))
                    return
                }
                single(.success(decodedData))
            }
            
            dataTask.resume()
            
            return Disposables.create()
        }
    }
}
