//
//  UIPageViewController+Rx.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/14.
//

import UIKit
import RxCocoa
import RxSwift

final class RxUIPageViewControllerDelegateProxy: DelegateProxy<UIPageViewController, UIPageViewControllerDelegate>,
                                                 DelegateProxyType,
                                                 UIPageViewControllerDelegate {
    static func registerKnownImplementations() {
        self.register(make: { pageViewController -> RxUIPageViewControllerDelegateProxy in
            RxUIPageViewControllerDelegateProxy(
                parentObject: pageViewController,
                delegateProxy: self
            )
        })
    }
    
    static func currentDelegate(for object: UIPageViewController) -> UIPageViewControllerDelegate? {
        object.delegate
    }
    
    static func setCurrentDelegate(_ delegate: UIPageViewControllerDelegate?, to object: UIPageViewController) {
        object.delegate = delegate
    }
}

extension Reactive where Base: UIPageViewController {
    
    // MARK: - delegate
    
    var delegate: DelegateProxy<UIPageViewController, UIPageViewControllerDelegate> {
        return RxUIPageViewControllerDelegateProxy.proxy(for: self.base)
    }

    var gestureDrivenTransitionCompleted: Observable<Void> {
        return delegate.methodInvoked(
            #selector(UIPageViewControllerDelegate.pageViewController(_:didFinishAnimating:previousViewControllers:transitionCompleted:))
        )
        .map { _ in }
    }
    
}
