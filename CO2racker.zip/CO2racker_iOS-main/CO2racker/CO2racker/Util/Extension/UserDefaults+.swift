//
//  UserDefaults+.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/28.
//

import Foundation

extension UserDefaults {
    private enum UserDefaultsKeys {
        static let accessToken = "accessToken"
    }
    
    class var accessToken: String? {
        get { standard.string(forKey: UserDefaultsKeys.accessToken) }
        set {
            if let newValue {
                standard.set(newValue, forKey: UserDefaultsKeys.accessToken)
            } else {
                standard.removeObject(forKey: UserDefaultsKeys.accessToken)
            }
        }
    }
}
