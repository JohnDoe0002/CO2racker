//
//  UIImage+.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/17.
//

import UIKit

extension UIImage {
    static let goldMedal = UIImage(named: "gold_medal") ?? UIImage()
    static let silverMedal = UIImage(named: "silver_medal") ?? UIImage()
    static let bronzeMedal = UIImage(named: "bronze_medal") ?? UIImage()
    static let coffeeImage = UIImage(named: "coffee") ?? UIImage()
    static let gifticonImage = UIImage(named: "gifticon") ?? UIImage()
    static let coffeeThumbnailImage = UIImage(named: "coffee_thumbnail") ?? UIImage()
}
