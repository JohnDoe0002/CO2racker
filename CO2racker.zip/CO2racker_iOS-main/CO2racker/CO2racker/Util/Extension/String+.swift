//
//  String+.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/05/16.
//

import Foundation

extension String {
    func toDate() -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS"      // 2023-05-16T15:55:24.977298
        return dateFormatter.date(from: self)
    }
}
