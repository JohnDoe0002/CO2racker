//
//  UIView+.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/04/20.
//

import UIKit

extension UIView {
    enum ShadowDirection {
        case top, bottom, left, right
    }
    
    func addShadow(offset: CGSize, color: UIColor = .gray, opacity: Float = 0.5, radius: CGFloat = 3) {
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius
        self.layer.shadowOffset = offset
    }
}
