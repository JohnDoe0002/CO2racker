//
//  UITextField+.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/03/28.
//

import UIKit

extension UITextField {
    func addLeftPadding() {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: frame.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
}
