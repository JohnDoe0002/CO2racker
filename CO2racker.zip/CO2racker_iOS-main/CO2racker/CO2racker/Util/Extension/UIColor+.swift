//
//  UIColor+.swift
//  CO2racker
//
//  Created by  sangyeon on 2023/03/28.
//

import UIKit

extension UIColor {
    static let mainColor = UIColor(named: "MainColor") ?? .red
    static let systemGray1 = UIColor(named: "SystemGray1") ?? .red
    static let systemGray2 = UIColor(named: "SystemGray2") ?? .red
    static let systemGray3 = UIColor(named: "SystemGray3") ?? .red
    static let systemGray4 = UIColor(named: "SystemGray4") ?? .red
}
