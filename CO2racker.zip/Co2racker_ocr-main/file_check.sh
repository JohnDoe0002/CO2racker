#!/bin/bash

IMG_0="/workspace/easy_ocr/images/cam0.jpg"
IMG_1="/workspace/easy_ocr/images/cam1.jpg"
IMG_2="/workspace/easy_ocr/images/cam2.jpg"

if [ -f "$IMG_0" -a -f "$IMG_1" -a -f "$IMG_2" ]; then
    /usr/local/bin/python /workspace/easy_ocr/easy_ocr.py
fi