import easyocr
import pymysql
from datetime import datetime
import os

result = [2,2,2]

def readRecord():
    reader = easyocr.Reader(['en'], gpu=False)
    for i in range(3):
        #text = reader.readtext('/workspace/easy_ocr/images/cam{}.jpg'.format(i), detail=False)
        #print(text)
        #result.append(int(text[1]))
        os.remove('/workspace/easy_ocr/images/cam{}.jpg'.format(i))
    storeDB()
    return("완료!")
        
        
def storeDB():
    conn= pymysql.connect(host='52.78.193.172',port=59688,user='dev', password='admin###', db = 'tanso',charset='utf8')
    cur = conn.cursor()
    # 전기 type = 0 , 가스 type = 1, 수도 type = 2
    for i in range(3):
        cur.execute('INSERT INTO tb_comsumption (status,area,consumed,type,user_id,created_at,updated_at) VALUES (%s, %s, %s, %s, %s, %s, %s)',
                    (1,'미추홀구',result[i], i,8 , datetime.today().strftime("%Y-%m-%d %H:%M:%S"),datetime.today().strftime("%Y-%m-%d %H:%M:%S") ))
    conn.commit()
    conn.close()
    return
